# The Writer's Spiral — Flutter App

A complete personal writing workshop app for Android, designed for theatre practitioners and scriptwriters.

---

## Features

| Feature | Details |
|---|---|
| **6 Phases, Locked Progression** | Phase 2–6 unlock after completing exercise milestones |
| **Exercises with Timer** | Countdown timer for each exercise, pause/reset |
| **Writing Pad** | Full-screen editor with auto-save every 3 seconds |
| **Focus Mode** | Distraction-free full-screen writing |
| **Word Count** | Live word count + session duration |
| **Streaks** | Current streak + best streak tracking |
| **Writing Journal** | All entries with search + phase filter |
| **Import Writing** | Import .txt and .md files |
| **Analytics** | Bar chart, writing calendar, phase progress, journey timeline |
| **Prompt Bank** | 40+ curated prompts across 8 categories |
| **AI Prompts** | Claude AI generates fresh prompts (optional, needs API key) |
| **Favorites** | Favorite prompts for quick access |
| **Daily Tasks** | Brain Drain + Exercise + Observation tasks each day |

---

## Setup Instructions

### 1. Install Flutter
```bash
# Install Flutter SDK from https://flutter.dev/docs/get-started/install
# Make sure to add flutter to your PATH

flutter --version  # Should show Flutter 3.x+
```

### 2. Clone / Copy the project
Copy this entire `writers_spiral` folder to your machine.

### 3. Install dependencies
```bash
cd writers_spiral
flutter pub get
```

### 4. Run on Android
Connect your Android phone via USB with USB debugging enabled, or use an emulator:
```bash
flutter run
```

To build an APK to install directly:
```bash
flutter build apk --release
# APK will be at: build/app/outputs/flutter-apk/app-release.apk
```

Transfer the APK to your phone and install it.

### 5. (Optional) AI Features Setup
To enable AI prompt generation:
1. Get a free API key from https://console.anthropic.com
2. In the app, go to Settings (gear icon on home screen)
3. Enter your Anthropic API key
4. AI prompts will now generate in the Prompt Bank screen

---

## App Structure

```
lib/
├── main.dart                    # App entry + bottom navigation
├── models/
│   └── models.dart              # All data models (Phase, Exercise, WritingEntry, etc.)
├── services/
│   ├── app_state.dart           # Central state management (Provider)
│   ├── database_service.dart    # SQLite persistence
│   ├── workshop_data.dart       # All 6 phases, modules, exercises, prompts
│   └── ai_service.dart          # Anthropic API integration
├── screens/
│   ├── home_screen.dart         # Dashboard, daily tasks, streak, current phase
│   ├── workshop_screen.dart     # All phases with lock/unlock system
│   ├── exercise_screen.dart     # Exercise view with timer and writing pad
│   ├── write_screen.dart        # Full writing editor with auto-save
│   ├── journal_screen.dart      # All writing entries, search, import
│   ├── analytics_screen.dart    # Charts, calendar, journey timeline
│   └── prompt_screen.dart       # Prompt bank with AI generation
└── utils/
    └── app_theme.dart           # Dark theme, colors, fonts, constants
```

---

## Phase Unlock System

| Phase | Name | Unlocks After |
|---|---|---|
| Phase 1 | Ignition | Always available |
| Phase 2 | Building Blocks | 21 exercises |
| Phase 3 | The Script | 42 exercises |
| Phase 4 | Craft Deepening | 63 exercises |
| Phase 5 | Advanced Techniques | 90 exercises |
| Phase 6 | The Spiral | 120 exercises |

---

## Daily Workflow (How to use the app)

1. **Open the app** — Home screen shows your greeting, streak, and today's tasks
2. **Brain Drain** — Tap the Brain Drain task, open writing pad, write for 10 minutes freely
3. **Workshop Exercise** — Tap the Exercise task, go to Workshop, pick your current phase exercise
4. **Timer** — Hit Start on the exercise timer, open Writing Pad, write until done
5. **Complete** — Mark exercise as complete to earn progress toward unlocking phases
6. **Review** — Check Analytics to see your writing days, word counts, and journey

---

## Fonts Used
- **Playfair Display** — Titles and headings (elegant, literary)
- **Crimson Text** — Body writing content (readable, classic)
- **Source Serif 4** — UI labels and cards
- **Source Code Pro** — Data, stats, badges

All fonts load via Google Fonts (requires internet on first launch).

---

## Customization

### Add your own exercises
Edit `lib/services/workshop_data.dart` — add `Exercise` objects to any module.

### Change phase unlock requirements
Edit `lib/utils/app_theme.dart` → `AppConstants.phaseUnlockRequirements`

### Add more prompts
Add `WritingPrompt` objects to the list in `WorkshopData.getPromptBank()`

---

## Tech Stack
- Flutter 3.x (Dart)
- Provider (state management)
- SQLite via sqflite (local persistence)
- fl_chart (analytics charts)
- flutter_animate (animations)
- google_fonts (typography)
- Anthropic API (AI prompts — optional)
