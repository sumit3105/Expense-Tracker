import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'services/app_state.dart';
import 'utils/app_theme.dart';
import 'screens/home_screen.dart';
import 'screens/workshop_screen.dart';
import 'screens/write_screen.dart';
import 'screens/journal_screen.dart';
import 'screens/analytics_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: AppTheme.bgCard,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  runApp(
    ChangeNotifierProvider(
      create: (_) => AppState()..initialize(),
      child: const WritersSpiralApp(),
    ),
  );
}

class WritersSpiralApp extends StatelessWidget {
  const WritersSpiralApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "The Writer's Spiral",
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      home: const MainNavigation(),
    );
  }
}

class MainNavigation extends StatefulWidget {
  const MainNavigation({super.key});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    HomeScreen(),
    WorkshopScreen(),
    JournalScreen(),
    AnalyticsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          border: const Border(
            top: BorderSide(color: AppTheme.borderColor, width: 1),
          ),
        ),
        child: SafeArea(
          child: SizedBox(
            height: 64,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _NavItem(index: 0, current: _currentIndex, icon: Icons.home_outlined, activeIcon: Icons.home, label: "Home", onTap: () => setState(() => _currentIndex = 0)),
                _NavItem(index: 1, current: _currentIndex, icon: Icons.auto_stories_outlined, activeIcon: Icons.auto_stories, label: "Workshop", onTap: () => setState(() => _currentIndex = 1)),
                _WriteButton(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WriteScreen()))),
                _NavItem(index: 2, current: _currentIndex, icon: Icons.book_outlined, activeIcon: Icons.book, label: "Journal", onTap: () => setState(() => _currentIndex = 2)),
                _NavItem(index: 3, current: _currentIndex, icon: Icons.insights_outlined, activeIcon: Icons.insights, label: "Journey", onTap: () => setState(() => _currentIndex = 3)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final int index, current;
  final IconData icon, activeIcon;
  final String label;
  final VoidCallback onTap;

  const _NavItem({required this.index, required this.current, required this.icon, required this.activeIcon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isActive = index == current;
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(isActive ? activeIcon : icon, color: isActive ? AppTheme.goldPrimary : AppTheme.textMuted, size: 24),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(
            fontSize: 10,
            fontFamily: 'SourceCodePro',
            color: isActive ? AppTheme.goldPrimary : AppTheme.textMuted,
            fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
            letterSpacing: 0.5,
          )),
        ],
      ),
    );
  }
}

class _WriteButton extends StatelessWidget {
  final VoidCallback onTap;
  const _WriteButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 52,
        height: 52,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppTheme.goldPrimary, AppTheme.goldLight],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: AppTheme.goldPrimary.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 4))],
        ),
        child: const Icon(Icons.edit, color: AppTheme.bgDeep, size: 24),
      ),
    );
  }
}
