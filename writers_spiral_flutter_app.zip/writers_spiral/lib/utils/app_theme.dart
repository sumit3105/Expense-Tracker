import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // Core Palette — Deep ink, aged paper, gold accent
  static const Color bgDeep = Color(0xFF0D0F14);
  static const Color bgCard = Color(0xFF161923);
  static const Color bgElevated = Color(0xFF1E2330);
  static const Color borderColor = Color(0xFF2A3040);

  static const Color goldPrimary = Color(0xFFD4A853);
  static const Color goldLight = Color(0xFFECC97A);
  static const Color goldDim = Color(0xFF8A6B30);

  static const Color inkBlue = Color(0xFF4A9EE0);
  static const Color inkBlueDim = Color(0xFF2A5F8A);

  static const Color crimson = Color(0xFFE05555);
  static const Color emerald = Color(0xFF4ABA7A);
  static const Color violet = Color(0xFF9B6DFF);

  static const Color textPrimary = Color(0xFFF0EDE8);
  static const Color textSecondary = Color(0xFFA09890);
  static const Color textMuted = Color(0xFF5A5550);

  static const Color locked = Color(0xFF2A2F3A);
  static const Color lockedBorder = Color(0xFF353D4A);

  // Phase Colors
  static const List<Color> phaseColors = [
    Color(0xFFE05555), // Phase 1 - Ignition - Red
    Color(0xFFD4A853), // Phase 2 - Building - Gold
    Color(0xFF4ABA7A), // Phase 3 - Script - Green
    Color(0xFF4A9EE0), // Phase 4 - Deepening - Blue
    Color(0xFF9B6DFF), // Phase 5 - Advanced - Violet
    Color(0xFFE07B40), // Phase 6 - Spiral - Orange
  ];

  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bgDeep,
      colorScheme: const ColorScheme.dark(
        primary: goldPrimary,
        secondary: inkBlue,
        surface: bgCard,
        background: bgDeep,
        onPrimary: bgDeep,
        onSecondary: textPrimary,
        onSurface: textPrimary,
      ),
      textTheme: GoogleFonts.crimsonTextTextTheme(
        ThemeData.dark().textTheme.copyWith(
          displayLarge: GoogleFonts.playfairDisplay(
            fontSize: 36, fontWeight: FontWeight.w700, color: textPrimary,
            letterSpacing: -0.5,
          ),
          displayMedium: GoogleFonts.playfairDisplay(
            fontSize: 28, fontWeight: FontWeight.w600, color: textPrimary,
          ),
          displaySmall: GoogleFonts.playfairDisplay(
            fontSize: 22, fontWeight: FontWeight.w600, color: textPrimary,
          ),
          headlineMedium: GoogleFonts.playfairDisplay(
            fontSize: 20, fontWeight: FontWeight.w600, color: textPrimary,
          ),
          titleLarge: GoogleFonts.sourceSerif4(
            fontSize: 18, fontWeight: FontWeight.w600, color: textPrimary,
          ),
          titleMedium: GoogleFonts.sourceSerif4(
            fontSize: 16, fontWeight: FontWeight.w500, color: textPrimary,
          ),
          bodyLarge: GoogleFonts.crimsonText(
            fontSize: 17, color: textPrimary, height: 1.6,
          ),
          bodyMedium: GoogleFonts.crimsonText(
            fontSize: 15, color: textSecondary, height: 1.5,
          ),
          labelLarge: GoogleFonts.sourceCodePro(
            fontSize: 12, fontWeight: FontWeight.w600, color: textPrimary,
            letterSpacing: 1.2,
          ),
          labelMedium: GoogleFonts.sourceCodePro(
            fontSize: 11, color: textSecondary, letterSpacing: 0.8,
          ),
        ),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: bgDeep,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: GoogleFonts.playfairDisplay(
          fontSize: 22, fontWeight: FontWeight.w700, color: textPrimary,
        ),
        iconTheme: const IconThemeData(color: textPrimary),
      ),
      cardTheme: CardTheme(
        color: bgCard,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: borderColor, width: 1),
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: bgCard,
        selectedItemColor: goldPrimary,
        unselectedItemColor: textMuted,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
      ),
    );
  }
}

class AppConstants {
  static const String appName = "The Writer's Spiral";
  static const String dbName = "writers_spiral.db";

  // Phases and their unlock requirements
  static const List<int> phaseUnlockRequirements = [
    0,  // Phase 1 always unlocked
    21, // Phase 2 unlocks after 21 exercises
    42, // Phase 3
    63, // Phase 4
    90, // Phase 5
    120, // Phase 6
  ];

  static const List<String> phaseNames = [
    "Ignition",
    "Building Blocks",
    "The Script",
    "Craft Deepening",
    "Advanced Techniques",
    "The Spiral",
  ];

  static const List<String> phaseSubtitles = [
    "Waking the Brain",
    "Story, Character & Scene",
    "Dialogue, Format & Direction",
    "Subtext, Theme & Rewriting",
    "Adaptation, Genre & Voice",
    "A Writer's Life — Forever",
  ];

  static const List<String> phaseDescriptions = [
    "Remove the fear of the blank page. These exercises are so small, so quick that your brain has no excuse. Repetition is the only rule.",
    "Shape the raw material. Learn the fundamental building blocks of all storytelling — what every great story shares.",
    "Go fully into the craft of scriptwriting. Tackle dialogue, stage directions, formatting, and the deeper craft beneath them.",
    "Where good writing becomes great. Go underneath the surface into the invisible architecture — theme, subtext, rewriting.",
    "Expand your toolkit with advanced techniques. Adaptation, genre awareness, and the development of your unique voice.",
    "The spiral continues forever. Build a daily practice and a writer's philosophy that will never stop growing.",
  ];

  static const int dailyBrainDrainTarget = 3; // lines
  static const int focusTimerMinutes = 25; // Pomodoro
}
