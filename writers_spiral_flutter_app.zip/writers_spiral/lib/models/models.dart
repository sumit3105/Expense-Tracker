import 'dart:convert';

// ==================== WORKSHOP DATA MODELS ====================

class Phase {
  final int id;
  final String name;
  final String subtitle;
  final String description;
  final List<Module> modules;
  bool isUnlocked;
  int completedExercises;

  Phase({
    required this.id,
    required this.name,
    required this.subtitle,
    required this.description,
    required this.modules,
    this.isUnlocked = false,
    this.completedExercises = 0,
  });

  int get totalExercises => modules.fold(0, (sum, m) => sum + m.exercises.length);
  double get progressPercent => totalExercises > 0 ? completedExercises / totalExercises : 0.0;
  bool get isComplete => completedExercises >= totalExercises;
}

class Module {
  final int id;
  final int phaseId;
  final String title;
  final String theory;
  final List<Exercise> exercises;
  int completedCount;

  Module({
    required this.id,
    required this.phaseId,
    required this.title,
    required this.theory,
    required this.exercises,
    this.completedCount = 0,
  });

  bool get isComplete => completedCount >= exercises.length;
  double get progress => exercises.isEmpty ? 0 : completedCount / exercises.length;
}

class Exercise {
  final String id;
  final int moduleId;
  final int phaseId;
  final String title;
  final String instruction;
  final String? prompt;
  final ExerciseType type;
  final int estimatedMinutes;
  bool isCompleted;
  DateTime? completedAt;

  Exercise({
    required this.id,
    required this.moduleId,
    required this.phaseId,
    required this.title,
    required this.instruction,
    this.prompt,
    required this.type,
    required this.estimatedMinutes,
    this.isCompleted = false,
    this.completedAt,
  });
}

enum ExerciseType {
  freeWrite,
  sceneWrite,
  characterWork,
  dialogueWork,
  observation,
  reading,
  watching,
  rewrite,
  adaptation,
  prompt,
}

// ==================== WRITING ENTRY MODELS ====================

class WritingEntry {
  final String id;
  String title;
  String content;
  String? exerciseId;
  String? exerciseTitle;
  int phaseId;
  DateTime createdAt;
  DateTime updatedAt;
  int wordCount;
  List<String> tags;

  WritingEntry({
    required this.id,
    required this.title,
    required this.content,
    this.exerciseId,
    this.exerciseTitle,
    this.phaseId = 1,
    required this.createdAt,
    required this.updatedAt,
    this.wordCount = 0,
    this.tags = const [],
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'title': title,
    'content': content,
    'exerciseId': exerciseId,
    'exerciseTitle': exerciseTitle,
    'phaseId': phaseId,
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
    'wordCount': wordCount,
    'tags': jsonEncode(tags),
  };

  factory WritingEntry.fromMap(Map<String, dynamic> map) => WritingEntry(
    id: map['id'],
    title: map['title'],
    content: map['content'],
    exerciseId: map['exerciseId'],
    exerciseTitle: map['exerciseTitle'],
    phaseId: map['phaseId'] ?? 1,
    createdAt: DateTime.parse(map['createdAt']),
    updatedAt: DateTime.parse(map['updatedAt']),
    wordCount: map['wordCount'] ?? 0,
    tags: List<String>.from(jsonDecode(map['tags'] ?? '[]')),
  );
}

// ==================== PROGRESS MODELS ====================

class UserProgress {
  int totalExercisesCompleted;
  int currentStreak;
  int bestStreak;
  DateTime? lastWritingDate;
  int totalWordsWritten;
  int currentPhase;
  List<String> completedExerciseIds;
  Map<String, int> dailyWordCounts; // date -> wordCount
  int totalSessions;
  int totalMinutesWritten;

  UserProgress({
    this.totalExercisesCompleted = 0,
    this.currentStreak = 0,
    this.bestStreak = 0,
    this.lastWritingDate,
    this.totalWordsWritten = 0,
    this.currentPhase = 1,
    this.completedExerciseIds = const [],
    this.dailyWordCounts = const {},
    this.totalSessions = 0,
    this.totalMinutesWritten = 0,
  });

  bool get wroteToday {
    if (lastWritingDate == null) return false;
    final now = DateTime.now();
    return lastWritingDate!.year == now.year &&
           lastWritingDate!.month == now.month &&
           lastWritingDate!.day == now.day;
  }

  Map<String, dynamic> toMap() => {
    'totalExercisesCompleted': totalExercisesCompleted,
    'currentStreak': currentStreak,
    'bestStreak': bestStreak,
    'lastWritingDate': lastWritingDate?.toIso8601String(),
    'totalWordsWritten': totalWordsWritten,
    'currentPhase': currentPhase,
    'completedExerciseIds': jsonEncode(completedExerciseIds),
    'dailyWordCounts': jsonEncode(dailyWordCounts),
    'totalSessions': totalSessions,
    'totalMinutesWritten': totalMinutesWritten,
  };

  factory UserProgress.fromMap(Map<String, dynamic> map) => UserProgress(
    totalExercisesCompleted: map['totalExercisesCompleted'] ?? 0,
    currentStreak: map['currentStreak'] ?? 0,
    bestStreak: map['bestStreak'] ?? 0,
    lastWritingDate: map['lastWritingDate'] != null ? DateTime.parse(map['lastWritingDate']) : null,
    totalWordsWritten: map['totalWordsWritten'] ?? 0,
    currentPhase: map['currentPhase'] ?? 1,
    completedExerciseIds: List<String>.from(jsonDecode(map['completedExerciseIds'] ?? '[]')),
    dailyWordCounts: Map<String, int>.from(jsonDecode(map['dailyWordCounts'] ?? '{}')),
    totalSessions: map['totalSessions'] ?? 0,
    totalMinutesWritten: map['totalMinutesWritten'] ?? 0,
  );
}

// ==================== DAILY TASK MODEL ====================

class DailyTask {
  final String id;
  final String title;
  final String description;
  final DailyTaskType type;
  final int targetMinutes;
  bool isCompleted;

  DailyTask({
    required this.id,
    required this.title,
    required this.description,
    required this.type,
    required this.targetMinutes,
    this.isCompleted = false,
  });
}

enum DailyTaskType {
  brainDrain,
  exercise,
  reading,
  watching,
  reflection,
}

// ==================== PROMPT BANK MODEL ====================

class WritingPrompt {
  final String id;
  final String text;
  final PromptCategory category;
  final int phaseId;
  bool isFavorited;
  bool isAIGenerated;

  WritingPrompt({
    required this.id,
    required this.text,
    required this.category,
    required this.phaseId,
    this.isFavorited = false,
    this.isAIGenerated = false,
  });
}

enum PromptCategory {
  character,
  scene,
  situation,
  title,
  object,
  dialogue,
  rewrite,
  adaptation,
  sensory,
  observation,
}
