import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/models.dart';

class AIService {
  // Uses Anthropic API - user needs to add their API key in settings
  static String _apiKey = '';

  static void setApiKey(String key) {
    _apiKey = key;
  }

  static Future<String?> generatePrompt({
    required PromptCategory category,
    required int phaseId,
    String? context,
  }) async {
    if (_apiKey.isEmpty) return null;

    final categoryName = category.name;
    final systemPrompt = '''You are a master writing workshop teacher helping a theatre practitioner and scriptwriter develop their craft.
Generate ONE creative, specific, evocative writing prompt for a ${categoryName} exercise in Phase $phaseId of their workshop.
The prompt should:
- Be specific and concrete, not vague
- Spark immediate imagination
- Be appropriate for someone who writes theatre scripts
- Be 1-3 sentences maximum
- Have emotional depth or dramatic potential
${context != null ? "Context about their recent writing: $context" : ""}
Respond with ONLY the prompt text, nothing else.''';

    try {
      final response = await http.post(
        Uri.parse('https://api.anthropic.com/v1/messages'),
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': _apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: jsonEncode({
          'model': 'claude-haiku-4-5-20251001',
          'max_tokens': 150,
          'messages': [
            {'role': 'user', 'content': 'Generate a $categoryName writing prompt for Phase $phaseId of a theatre writing workshop.'}
          ],
          'system': systemPrompt,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['content'][0]['text'] as String?;
      }
    } catch (e) {
      // Handle silently — AI is optional enhancement
    }
    return null;
  }

  static Future<String?> getWritingFeedback(String writingText, String exerciseTitle) async {
    if (_apiKey.isEmpty) return null;
    if (writingText.trim().length < 50) return null;

    try {
      final response = await http.post(
        Uri.parse('https://api.anthropic.com/v1/messages'),
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': _apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: jsonEncode({
          'model': 'claude-haiku-4-5-20251001',
          'max_tokens': 300,
          'messages': [
            {
              'role': 'user',
              'content': 'This is a theatre writing exercise: "$exerciseTitle"\n\nHere is the writing:\n\n$writingText\n\nGive brief, specific, encouraging feedback in 2-3 sentences. Focus on one strength and one specific thing to develop. Be like a warm but direct writing teacher.'
            }
          ],
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['content'][0]['text'] as String?;
      }
    } catch (e) {
      // Silent failure
    }
    return null;
  }
}
