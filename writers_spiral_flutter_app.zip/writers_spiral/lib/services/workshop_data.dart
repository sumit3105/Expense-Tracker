import '../models/models.dart';

class WorkshopData {
  static List<Phase> getAllPhases() {
    return [
      _buildPhase1(),
      _buildPhase2(),
      _buildPhase3(),
      _buildPhase4(),
      _buildPhase5(),
      _buildPhase6(),
    ];
  }

  static Phase _buildPhase1() {
    return Phase(
      id: 1,
      name: "Ignition",
      subtitle: "Waking the Brain",
      description: "Remove the fear of the blank page. These exercises are so small, so non-threatening that your brain has no excuse. Repetition is the only rule.",
      isUnlocked: true,
      modules: [
        Module(
          id: 101,
          phaseId: 1,
          title: "Free Writing: The Vomit Draft",
          theory: "Free writing is the most powerful tool to unlock a stuck mind. Write without stopping, without editing, without thinking about quality. Your pen or cursor moves constantly for a fixed time.\n\nThe brain censors itself constantly. Free writing bypasses the censor. It accesses raw material that your conscious, editing mind would never allow through.",
          exercises: [
            Exercise(
              id: "1_1_1",
              moduleId: 101,
              phaseId: 1,
              title: "The 5-Minute Vomit",
              instruction: "Set a timer for 5 minutes. Start writing and DO NOT STOP. Do not correct spelling. Do not reread. Do not cross out. Just write whatever comes. If you have nothing, write 'I have nothing to write' until something else comes.",
              prompt: "The last time I was truly surprised was...",
              type: ExerciseType.freeWrite,
              estimatedMinutes: 5,
            ),
            Exercise(
              id: "1_1_2",
              moduleId: 101,
              phaseId: 1,
              title: "Object Vomit",
              instruction: "Pick any object near you right now. Write about it for 5 minutes. Not a description — write whatever it makes you feel, remember, imagine. A pen can become a story. A cup can become a confession.",
              prompt: "Look around you. Pick one object. Begin writing about it without thinking.",
              type: ExerciseType.freeWrite,
              estimatedMinutes: 5,
            ),
            Exercise(
              id: "1_1_3",
              moduleId: 101,
              phaseId: 1,
              title: "The Daily Brain Drain",
              instruction: "Write 10 minutes of free writing. No prompt. No rules. Just write. This is your most important daily habit. Do not share it with anyone. This is your private brain space.",
              prompt: "Open the page and begin. Don't wait for a feeling or idea. Start anywhere.",
              type: ExerciseType.freeWrite,
              estimatedMinutes: 10,
            ),
            Exercise(
              id: "1_1_4",
              moduleId: 101,
              phaseId: 1,
              title: "The Memory Flood",
              instruction: "Write for 7 minutes about a specific moment from your childhood. Not the whole story — just one specific moment. A smell, a room, a sound, a face. Start in the middle of the action.",
              prompt: "A room I remember from childhood. I am there now...",
              type: ExerciseType.freeWrite,
              estimatedMinutes: 7,
            ),
          ],
        ),
        Module(
          id: 102,
          phaseId: 1,
          title: "Word Games & Association",
          theory: "The writer's brain runs on association — the ability to connect unexpected things. These exercises build that muscle. They are quick, playful, and train you to see connections everywhere.",
          exercises: [
            Exercise(
              id: "1_2_1",
              moduleId: 102,
              phaseId: 1,
              title: "Word Chain",
              instruction: "Write one word. Then write the first word that comes to your mind from it. Then from that word. Build a chain of 20 words. Then look at the first and last word and write one sentence that connects them.",
              prompt: "Start with the word: RAIN",
              type: ExerciseType.freeWrite,
              estimatedMinutes: 8,
            ),
            Exercise(
              id: "1_2_2",
              moduleId: 102,
              phaseId: 1,
              title: "Wrong Combinations",
              instruction: "Combine two completely unrelated things and write 3 sentences about them as if they belong together. Do this for 5 pairs. This is how great scenes are born — from unexpected combinations.",
              prompt: "Pairs: 1. A doctor and a kite  2. A wedding and a power cut  3. An old man and a sports car  4. A child and a court hearing  5. A love letter and a traffic jam",
              type: ExerciseType.freeWrite,
              estimatedMinutes: 12,
            ),
            Exercise(
              id: "1_2_3",
              moduleId: 102,
              phaseId: 1,
              title: "Sensory Lists",
              instruction: "Write 5 things for each category. Do it fast, do not overthink. Then take one item and write a paragraph using that sensory detail as the anchor.",
              prompt: "5 sounds that make you feel safe | 5 smells that carry a memory | 5 textures that feel like sadness | 5 colours that feel like anger",
              type: ExerciseType.freeWrite,
              estimatedMinutes: 15,
            ),
            Exercise(
              id: "1_2_4",
              moduleId: 102,
              phaseId: 1,
              title: "The Six-Word Story",
              instruction: "Write 10 six-word stories. They must have a beginning, middle, and an emotional punch. Hemingway's example: 'For sale: baby shoes, never worn.'",
              prompt: "Begin. Each line is a complete world.",
              type: ExerciseType.freeWrite,
              estimatedMinutes: 10,
            ),
          ],
        ),
        Module(
          id: 103,
          phaseId: 1,
          title: "Observation Exercises",
          theory: "Writers are professional observers. They watch the world differently. They notice the way a person adjusts their glasses when they lie. Your job is to train your eyes and ears. The world around you is a library of characters, scenes, and stories.",
          exercises: [
            Exercise(
              id: "1_3_1",
              moduleId: 103,
              phaseId: 1,
              title: "People Watching: Character Sketch",
              instruction: "Go to a public place. Pick one stranger. Observe them for 2-3 minutes. Then write: (1) 3 specific physical details, (2) what their action tells you, (3) one secret they might be carrying today, (4) one line of dialogue they might say right now.",
              prompt: "Find your stranger. Watch without being noticed. Then write.",
              type: ExerciseType.observation,
              estimatedMinutes: 20,
            ),
            Exercise(
              id: "1_3_2",
              moduleId: 103,
              phaseId: 1,
              title: "The Conversation Transcript",
              instruction: "Listen to a real conversation around you. Write down what you hear as closely as possible. Then read it back. Notice: how different is real speech from what we write as dialogue? What filler, interruption, and repetition exists in real talk?",
              prompt: "Listen first. Then write exactly what you heard.",
              type: ExerciseType.observation,
              estimatedMinutes: 15,
            ),
            Exercise(
              id: "1_3_3",
              moduleId: 103,
              phaseId: 1,
              title: "Location Diary",
              instruction: "Visit a different location this week — a temple, market, hospital, park. Spend 15 minutes just observing. Then write one page about what you saw, heard, felt. Not a report. A piece of writing.",
              prompt: "Choose your location. Go there. Observe. Then write one page.",
              type: ExerciseType.observation,
              estimatedMinutes: 30,
            ),
          ],
        ),
      ],
    );
  }

  static Phase _buildPhase2() {
    return Phase(
      id: 2,
      name: "Building Blocks",
      subtitle: "Story, Character & Scene",
      description: "Shape the raw material. Learn the fundamental building blocks of all storytelling — what every great story shares beneath its surface.",
      isUnlocked: false,
      modules: [
        Module(
          id: 201,
          phaseId: 2,
          title: "What Is a Story? The Spine",
          theory: "Every story — from a 30-second joke to a 3-hour play — has the same spine. A character wants something. Something stands in the way. The character does something about it. Things change.\n\nThe Story Spine: Once upon a time... / Every day... / Until one day... / Because of that... / Until finally... / And ever since then...",
          exercises: [
            Exercise(
              id: "2_1_1",
              moduleId: 201,
              phaseId: 2,
              title: "Story Spine Practice",
              instruction: "Write 5 short story spines using the Story Spine formula. They can be simple. They can be absurd. The goal is to feel how all stories follow this shape. Try: hospital, village, about an object, about old friends, about a city.",
              prompt: "Once upon a time, in a government hospital...",
              type: ExerciseType.freeWrite,
              estimatedMinutes: 20,
            ),
            Exercise(
              id: "2_1_2",
              moduleId: 201,
              phaseId: 2,
              title: "What Does Your Character Want?",
              instruction: "For each scenario, write what the character wants on the surface AND what they REALLY want underneath. The gap between these two things IS the drama.",
              prompt: "1. A man arguing with his boss about a promotion\n2. A woman returning to her hometown after 10 years\n3. A teenager refusing to eat dinner\n4. Two friends who stop talking",
              type: ExerciseType.characterWork,
              estimatedMinutes: 15,
            ),
          ],
        ),
        Module(
          id: 202,
          phaseId: 2,
          title: "Character: Building People from Scratch",
          theory: "Characters are not descriptions. They are decisions. Every character is defined by what they DO, not how they look. A character becomes real when they make choices that surprise us — but feel inevitable in hindsight.\n\nGreat characters are specific, contradictory, and want something.",
          exercises: [
            Exercise(
              id: "2_2_1",
              moduleId: 202,
              phaseId: 2,
              title: "The Character Questionnaire",
              instruction: "Answer all 7 questions for a character you invent RIGHT NOW. Write each answer as a small piece of prose, not a list.",
              prompt: "1. One physical habit when nervous?\n2. The last lie they told, and to whom?\n3. What they do alone that would embarrass them?\n4. One thing they believe the world calls wrong?\n5. One thing they lost and never talked about?\n6. What makes them laugh when nothing else can?\n7. First thing they do every morning?",
              type: ExerciseType.characterWork,
              estimatedMinutes: 25,
            ),
            Exercise(
              id: "2_2_2",
              moduleId: 202,
              phaseId: 2,
              title: "Character Contradiction",
              instruction: "Write a paragraph showing a character who is BOTH things at once. Show both qualities through action — not description. Do this for each pair.",
              prompt: "1. Generous but deeply selfish\n2. Brave but terrified of one small thing\n3. Funny but secretly heartbroken\n4. Powerful but obedient to someone else",
              type: ExerciseType.characterWork,
              estimatedMinutes: 20,
            ),
            Exercise(
              id: "2_2_3",
              moduleId: 202,
              phaseId: 2,
              title: "Character Monologue",
              instruction: "Write a 200-word monologue in the voice of a character you created. The monologue must reveal something they would NOT normally say out loud. They are confessing, justifying, or remembering.",
              prompt: "Your character is alone. No one is watching. They speak what they have never said.",
              type: ExerciseType.freeWrite,
              estimatedMinutes: 20,
            ),
          ],
        ),
        Module(
          id: 203,
          phaseId: 2,
          title: "The Scene: Basic Unit of Drama",
          theory: "A scene is a unit of dramatic action. Every scene must: reveal character, advance plot, or create conflict. A scene that does none of these should be cut.\n\nEnter late. Exit early. Something must CHANGE by the end of every scene.",
          exercises: [
            Exercise(
              id: "2_3_1",
              moduleId: 203,
              phaseId: 2,
              title: "Enter Late, Exit Early",
              instruction: "Two people are having a fight about money. Write the scene starting 3 lines before the fight reaches its peak — NOT from the beginning. End the scene 2 lines after the breaking point — NOT with resolution.",
              prompt: "The fight is almost at its worst. Start here.",
              type: ExerciseType.sceneWrite,
              estimatedMinutes: 20,
            ),
            Exercise(
              id: "2_3_2",
              moduleId: 203,
              phaseId: 2,
              title: "The Silent Scene",
              instruction: "Write a scene between two characters in which NO dialogue is spoken. Communicate everything — the relationship, the conflict, the emotion — purely through action and stage direction.",
              prompt: "Two people. One room. Something is wrong between them. No words.",
              type: ExerciseType.sceneWrite,
              estimatedMinutes: 20,
            ),
            Exercise(
              id: "2_3_3",
              moduleId: 203,
              phaseId: 2,
              title: "Scene Rewrite",
              instruction: "Take a scene from any play, film, or TV show you know. Rewrite it by changing ONE major element: change the location, swap genders, reverse the power dynamic, or change the time period. Observe how everything shifts.",
              prompt: "Choose your scene. Choose your change. Begin.",
              type: ExerciseType.rewrite,
              estimatedMinutes: 30,
            ),
          ],
        ),
      ],
    );
  }

  static Phase _buildPhase3() {
    return Phase(
      id: 3,
      name: "The Script",
      subtitle: "Dialogue, Format & Direction",
      description: "Go fully into the craft of scriptwriting. Tackle the most visible elements — dialogue, stage directions — but more importantly, go into the deeper craft beneath them.",
      isUnlocked: false,
      modules: [
        Module(
          id: 301,
          phaseId: 3,
          title: "Dialogue: What Is Not Said",
          theory: "Dialogue in a script is not conversation. Real conversation is full of noise and filler. Scripted dialogue is surgically precise.\n\nThe most important rule: characters do NOT say what they mean. They talk around it. The audience feels the real meaning between the lines. This is called SUBTEXT — the difference between flat dialogue and electric dialogue.",
          exercises: [
            Exercise(
              id: "3_1_1",
              moduleId: 301,
              phaseId: 3,
              title: "Subtext Scenes",
              instruction: "Write a scene where the subject of conversation is one thing but the REAL subject is another. The audience should understand the real subject without it ever being named.",
              prompt: "Choose one: (a) Mother and daughter talking about cooking — really about control. (b) Old friends discussing cricket — really about betrayal. (c) Boss and employee on deadline — really about disrespect.",
              type: ExerciseType.dialogueWork,
              estimatedMinutes: 25,
            ),
            Exercise(
              id: "3_1_2",
              moduleId: 301,
              phaseId: 3,
              title: "Stripping Dialogue",
              instruction: "Take a scene of dialogue you wrote earlier. Go through every line and ask: does this line NEED to be here? Cut any line that can be removed without losing meaning. The scene becomes stronger by subtraction.",
              prompt: "Open a scene from your writing entries. Cut ruthlessly.",
              type: ExerciseType.rewrite,
              estimatedMinutes: 20,
            ),
            Exercise(
              id: "3_1_3",
              moduleId: 301,
              phaseId: 3,
              title: "Witty Dialogue Workout",
              instruction: "Complete all four tasks: (1) A character who answers every question with a question. (2) A character who never directly answers but whose answers are satisfying. (3) Rewrite 'I am very angry' five ways — never naming the emotion. (4) A scene where serious content keeps becoming accidentally funny.",
              prompt: "Four mini-scenes. Each shows a different wit technique.",
              type: ExerciseType.dialogueWork,
              estimatedMinutes: 30,
            ),
            Exercise(
              id: "3_1_4",
              moduleId: 301,
              phaseId: 3,
              title: "Voice Differentiation",
              instruction: "Create 3 characters: one who speaks in short punchy sentences, one in long circling paragraphs, one with lots of questions. Write a 3-way scene and commit to each voice rigorously. Remove names — can you tell who speaks?",
              prompt: "Three voices. One conversation. Each voice unmistakable.",
              type: ExerciseType.dialogueWork,
              estimatedMinutes: 30,
            ),
          ],
        ),
        Module(
          id: 302,
          phaseId: 3,
          title: "Stage Directions & Visual Language",
          theory: "Stage directions are not just instructions for the director. They are part of the writing. The best stage directions are specific, economical, and visual. They show — they do not explain. 'He looks sad' is direction. 'He aligns the spoons for the third time' is writing.",
          exercises: [
            Exercise(
              id: "3_2_1",
              moduleId: 302,
              phaseId: 3,
              title: "Rewrite the Stage Direction",
              instruction: "Bad direction: 'He sits down, looking sad. He is tired and worried about the future.' Rewrite this as a stage direction showing the same emotional state through specific physical action — without any emotion words.",
              prompt: "Show tired worry through action alone. No adjectives of feeling.",
              type: ExerciseType.rewrite,
              estimatedMinutes: 15,
            ),
            Exercise(
              id: "3_2_2",
              moduleId: 302,
              phaseId: 3,
              title: "The One-Line World",
              instruction: "In exactly one line of stage direction, set the scene so powerfully that the audience instantly knows the world, mood, and time. Write for each of these 4 settings.",
              prompt: "1. A middle-class living room, 1980s\n2. A hospital corridor at 3am\n3. A tea stall on a crowded street corner\n4. A young woman's bedroom morning after a breakup",
              type: ExerciseType.sceneWrite,
              estimatedMinutes: 15,
            ),
          ],
        ),
      ],
    );
  }

  static Phase _buildPhase4() {
    return Phase(
      id: 4,
      name: "Craft Deepening",
      subtitle: "Subtext, Theme & Rewriting",
      description: "Where good writing becomes great writing. Go underneath the surface into the invisible architecture — theme, subtext, and the sacred practice of rewriting.",
      isUnlocked: false,
      modules: [
        Module(
          id: 401,
          phaseId: 4,
          title: "Theme: What Is Your Play Really About?",
          theory: "A play is about a story on the surface. But underneath is a question the writer is asking the world. Theme is not a message or a moral — it is a question being explored.\n\nNot: 'This play is about how family is important.' But: 'Can a person ever truly return home?'",
          exercises: [
            Exercise(
              id: "4_1_1",
              moduleId: 401,
              phaseId: 4,
              title: "Finding the Theme Beneath",
              instruction: "Take any story idea you have. Ask yourself: what question does this story ask? Write the theme as a QUESTION, not a statement. Then prove it exists in your story by listing three moments where the theme surfaces.",
              prompt: "What question is your story asking the world?",
              type: ExerciseType.freeWrite,
              estimatedMinutes: 20,
            ),
            Exercise(
              id: "4_1_2",
              moduleId: 401,
              phaseId: 4,
              title: "Theme Layering",
              instruction: "Write a short scene (1 page) about a man missing his bus. Make it work simultaneously on: (1) Literal level — he is late. (2) Emotional level — he always misses his chances. (3) Thematic level — time moves on without waiting.",
              prompt: "A man at a bus stop. The bus just left. Write three layers at once.",
              type: ExerciseType.sceneWrite,
              estimatedMinutes: 25,
            ),
          ],
        ),
        Module(
          id: 402,
          phaseId: 4,
          title: "The Sacred Act of Rewriting",
          theory: "The first draft is you telling yourself the story. The second draft is you telling it to the audience. The third draft is you making it sing.\n\nProfessional writers know: writing IS rewriting. The vomit draft exists to be refined.",
          exercises: [
            Exercise(
              id: "4_2_1",
              moduleId: 402,
              phaseId: 4,
              title: "The Three-Pass Rewrite",
              instruction: "Take any scene you wrote in this workshop. Rewrite it three times: Pass 1 — Structure (does something change?). Pass 2 — Dialogue (is every line necessary? distinct voices?). Pass 3 — Polish (every word right? read it aloud).",
              prompt: "Choose your best scene from earlier. Begin Pass 1.",
              type: ExerciseType.rewrite,
              estimatedMinutes: 45,
            ),
            Exercise(
              id: "4_2_2",
              moduleId: 402,
              phaseId: 4,
              title: "The Brutal Cut",
              instruction: "Take a scene that is 2 pages long. Cut it to 1 page without losing any essential story or character information. This is one of the hardest and most important skills in scriptwriting.",
              prompt: "Your scene: half the words, all the meaning.",
              type: ExerciseType.rewrite,
              estimatedMinutes: 30,
            ),
          ],
        ),
      ],
    );
  }

  static Phase _buildPhase5() {
    return Phase(
      id: 5,
      name: "Advanced Techniques",
      subtitle: "Adaptation, Genre & Voice",
      description: "Expand your toolkit with advanced techniques. Adaptation, genre awareness, and the development of your unique voice as a writer.",
      isUnlocked: false,
      modules: [
        Module(
          id: 501,
          phaseId: 5,
          title: "Adaptation: Writing from Existing Material",
          theory: "Adaptation is one of the most productive exercises for any writer. Taking an existing story and reworking it for a different medium, time, or perspective teaches you more about structure than almost anything else.",
          exercises: [
            Exercise(
              id: "5_1_1",
              moduleId: 501,
              phaseId: 5,
              title: "Gender & Power Swap",
              instruction: "Take any well-known story — myth, classic play, Bollywood film. Swap the genders of all main characters. Rewrite the first scene with this change. Notice how power dynamics, dialogue, and assumptions shift.",
              prompt: "Choose your story. Swap genders. Begin the first scene.",
              type: ExerciseType.adaptation,
              estimatedMinutes: 30,
            ),
            Exercise(
              id: "5_1_2",
              moduleId: 501,
              phaseId: 5,
              title: "Time Travel Rewrite",
              instruction: "Take a classic story set in one time period. Move it to a completely different time. Try: Romeo & Juliet in divided Mumbai 1993. Or Mahabharata's court scene in a modern boardroom.",
              prompt: "Same story. Different era. What changes? What stays true?",
              type: ExerciseType.adaptation,
              estimatedMinutes: 35,
            ),
            Exercise(
              id: "5_1_3",
              moduleId: 501,
              phaseId: 5,
              title: "The Untold Perspective",
              instruction: "Every famous story has a secondary character who witnessed everything but whose story was never told. Write a scene from their perspective. Give them a full inner life.",
              prompt: "The servant at the feast. The guard at the gate. The younger sibling. Choose your witness.",
              type: ExerciseType.adaptation,
              estimatedMinutes: 30,
            ),
          ],
        ),
        Module(
          id: 502,
          phaseId: 5,
          title: "Genre: Using and Subverting Conventions",
          theory: "Genre is a set of audience expectations. The best writing knows the rules of the genre it is working in — and strategically breaks them. You cannot subvert a genre you do not understand.",
          exercises: [
            Exercise(
              id: "5_2_1",
              moduleId: 502,
              phaseId: 5,
              title: "Genre Crossing",
              instruction: "Take this scenario: A person discovers an old letter in a drawer that was never sent. Write it as (1) a thriller, (2) a quiet domestic drama, (3) a dark comedy. Same premise. Three completely different genre treatments.",
              prompt: "The letter exists. Three writers open it.",
              type: ExerciseType.sceneWrite,
              estimatedMinutes: 40,
            ),
          ],
        ),
        Module(
          id: 503,
          phaseId: 5,
          title: "Finding Your Voice",
          theory: "Voice is the feeling that this piece could only have been written by THIS person. Voice is built by writing a lot, reading widely, and being unafraid of your specific way of seeing the world.\n\nYour voice emerges through accumulation of honest, specific writing. Not by trying to sound like someone else.",
          exercises: [
            Exercise(
              id: "5_3_1",
              moduleId: 503,
              phaseId: 5,
              title: "The Specific Over the General",
              instruction: "Take 5 general statements and rewrite each as a specific, concrete action or image. GENERAL: 'She was sad about losing her job.' SPECIFIC: 'She drove home the long way and sat in the car outside her building for forty minutes before she could make herself go in.'",
              prompt: "1. He was angry. 2. They were in love. 3. She was afraid. 4. He missed his father. 5. They were celebrating.",
              type: ExerciseType.rewrite,
              estimatedMinutes: 20,
            ),
            Exercise(
              id: "5_3_2",
              moduleId: 503,
              phaseId: 5,
              title: "Write What Only You Can Write",
              instruction: "Write a scene set in a world only you truly know — your city, your background, your culture, your specific experience. Do not explain it for outsiders. Write it for someone who would immediately recognize it.",
              prompt: "What world do you know better than any outsider ever could?",
              type: ExerciseType.freeWrite,
              estimatedMinutes: 30,
            ),
          ],
        ),
      ],
    );
  }

  static Phase _buildPhase6() {
    return Phase(
      id: 6,
      name: "The Spiral",
      subtitle: "A Writer's Life — Forever",
      description: "The spiral continues forever. Every technique you learn opens three more. Every piece you write teaches you something new. This phase gives you practices and frameworks to keep growing for the rest of your writing life.",
      isUnlocked: false,
      modules: [
        Module(
          id: 601,
          phaseId: 6,
          title: "The Daily Writing Practice",
          theory: "The most important thing a writer can do is write every day. Not perfectly. Not for a long time. But every single day. The habit is everything. The habit is the writer.",
          exercises: [
            Exercise(
              id: "6_1_1",
              moduleId: 601,
              phaseId: 6,
              title: "The Monthly Review",
              instruction: "Sit with your writing from this month. Ask: (1) What am I proud of? Why? (2) What was hardest? What does that tell me? (3) One technique I used that I didn't last month. (4) What do I focus on next month? Write your answers.",
              prompt: "Look back. What have you built?",
              type: ExerciseType.reflection,
              estimatedMinutes: 20,
            ),
            Exercise(
              id: "6_1_2",
              moduleId: 601,
              phaseId: 6,
              title: "The Spiral Return",
              instruction: "Return to Exercise 1.1.1 — the 5-Minute Vomit. Do it again, exactly as instructed. Then compare what you write today to what you wrote when you first started. The difference between those two pieces is your growth.",
              prompt: "The last time I was truly surprised was...",
              type: ExerciseType.freeWrite,
              estimatedMinutes: 10,
            ),
          ],
        ),
      ],
    );
  }

  // ==================== PROMPT BANK ====================
  static List<WritingPrompt> getPromptBank() {
    return [
      // Character prompts
      WritingPrompt(id: "p_c1", text: "Write a character who can only express love through criticism.", category: PromptCategory.character, phaseId: 2),
      WritingPrompt(id: "p_c2", text: "Write a character who has been waiting for someone for 20 years. They are still waiting.", category: PromptCategory.character, phaseId: 2),
      WritingPrompt(id: "p_c3", text: "Write a character who only lies about small things, never big things. Why?", category: PromptCategory.character, phaseId: 2),
      WritingPrompt(id: "p_c4", text: "Write a character who laughs at funerals and cries at weddings. What is their story?", category: PromptCategory.character, phaseId: 2),
      WritingPrompt(id: "p_c5", text: "Two people who used to be best friends and now cannot stand each other — but neither will say why.", category: PromptCategory.character, phaseId: 2),

      // Scene prompts
      WritingPrompt(id: "p_s1", text: "Two strangers are stuck in a lift. One of them knows something about the other. They say nothing about it.", category: PromptCategory.scene, phaseId: 2),
      WritingPrompt(id: "p_s2", text: "A family is gathered for what they all think is a celebration. One person knows it is not.", category: PromptCategory.scene, phaseId: 2),
      WritingPrompt(id: "p_s3", text: "Write a scene where a goodbye is said but the word 'goodbye' is never used.", category: PromptCategory.scene, phaseId: 2),
      WritingPrompt(id: "p_s4", text: "Write a scene where the most powerful person in the room says the least.", category: PromptCategory.scene, phaseId: 3),
      WritingPrompt(id: "p_s5", text: "A child asks an adult a question the adult cannot answer honestly.", category: PromptCategory.scene, phaseId: 2),

      // Situation prompts
      WritingPrompt(id: "p_sit1", text: "The last train has left. Two people who should not be together are stuck in the same station.", category: PromptCategory.situation, phaseId: 1),
      WritingPrompt(id: "p_sit2", text: "A letter arrives 30 years late.", category: PromptCategory.situation, phaseId: 2),
      WritingPrompt(id: "p_sit3", text: "Two people have a conversation about the weather. It is the most important conversation of their lives.", category: PromptCategory.situation, phaseId: 3),
      WritingPrompt(id: "p_sit4", text: "Someone returns to the house they grew up in to find it completely changed.", category: PromptCategory.situation, phaseId: 2),
      WritingPrompt(id: "p_sit5", text: "A secret is about to be revealed. At the last moment, the keeper decides to keep it.", category: PromptCategory.situation, phaseId: 3),

      // Title prompts
      WritingPrompt(id: "p_t1", text: "The Second Invitation", category: PromptCategory.title, phaseId: 2),
      WritingPrompt(id: "p_t2", text: "Everything She Left Behind", category: PromptCategory.title, phaseId: 2),
      WritingPrompt(id: "p_t3", text: "The Man Who Always Arrived Early", category: PromptCategory.title, phaseId: 2),
      WritingPrompt(id: "p_t4", text: "One More Summer", category: PromptCategory.title, phaseId: 2),
      WritingPrompt(id: "p_t5", text: "The Apology That Never Came", category: PromptCategory.title, phaseId: 3),
      WritingPrompt(id: "p_t6", text: "Borrowed Time", category: PromptCategory.title, phaseId: 1),
      WritingPrompt(id: "p_t7", text: "The Last Good Day", category: PromptCategory.title, phaseId: 2),
      WritingPrompt(id: "p_t8", text: "What We Don't Say at Dinner", category: PromptCategory.title, phaseId: 3),
      WritingPrompt(id: "p_t9", text: "The Understudy", category: PromptCategory.title, phaseId: 4),
      WritingPrompt(id: "p_t10", text: "The Room That Was Always Locked", category: PromptCategory.title, phaseId: 2),

      // Object prompts
      WritingPrompt(id: "p_o1", text: "An old mobile phone that still works but belonged to a dead person.", category: PromptCategory.object, phaseId: 1),
      WritingPrompt(id: "p_o2", text: "A railway ticket that was never used.", category: PromptCategory.object, phaseId: 1),
      WritingPrompt(id: "p_o3", text: "A photograph with someone cut out of it.", category: PromptCategory.object, phaseId: 2),
      WritingPrompt(id: "p_o4", text: "A key that does not open anything in the house anymore.", category: PromptCategory.object, phaseId: 2),
      WritingPrompt(id: "p_o5", text: "A half-eaten birthday cake.", category: PromptCategory.object, phaseId: 1),

      // Dialogue prompts
      WritingPrompt(id: "p_d1", text: "Write a complete scene using only dialogue — no stage directions, no names. Identity must be clear from words alone.", category: PromptCategory.dialogue, phaseId: 3),
      WritingPrompt(id: "p_d2", text: "Write a fight scene where neither character raises their voice. No shouting. No anger words. But it is clearly a fight.", category: PromptCategory.dialogue, phaseId: 3),
      WritingPrompt(id: "p_d3", text: "Write a reconciliation scene where one person apologizes and the other makes it very difficult to accept.", category: PromptCategory.dialogue, phaseId: 4),

      // Adaptation prompts
      WritingPrompt(id: "p_a1", text: "Take the Ramayana and rewrite one key scene as a political press conference.", category: PromptCategory.adaptation, phaseId: 5),
      WritingPrompt(id: "p_a2", text: "Take any folk tale from your region and adapt it for two characters in a modern setting.", category: PromptCategory.adaptation, phaseId: 5),
      WritingPrompt(id: "p_a3", text: "Take a Bollywood song and write the scene that exists before and after it.", category: PromptCategory.adaptation, phaseId: 5),
    ];
  }
}
