import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../models/models.dart';
import '../services/database_service.dart';
import '../services/workshop_data.dart';
import '../utils/app_theme.dart';

class AppState extends ChangeNotifier {
  final DatabaseService _db = DatabaseService();
  final _uuid = const Uuid();

  List<Phase> _phases = [];
  List<WritingEntry> _writingEntries = [];
  UserProgress _progress = UserProgress();
  List<WritingPrompt> _prompts = [];
  List<String> _favoritedPromptIds = [];
  bool _isLoading = true;

  List<Phase> get phases => _phases;
  List<WritingEntry> get writingEntries => _writingEntries;
  UserProgress get progress => _progress;
  List<WritingPrompt> get prompts => _prompts;
  bool get isLoading => _isLoading;

  // Current phase (for display)
  Phase? get currentPhase {
    if (_phases.isEmpty) return null;
    // Find the last unlocked phase with incomplete exercises
    for (int i = _phases.length - 1; i >= 0; i--) {
      if (_phases[i].isUnlocked && !_phases[i].isComplete) return _phases[i];
    }
    return _phases.where((p) => p.isUnlocked).lastOrNull;
  }

  Future<void> initialize() async {
    _isLoading = true;
    notifyListeners();

    _progress = await _db.getProgress();
    _writingEntries = await _db.getAllWritingEntries();
    _prompts = WorkshopData.getPromptBank();
    _favoritedPromptIds = await _db.getFavoritedPromptIds();

    // Load phases and mark completed exercises
    final completedIds = await _db.getCompletedExerciseIds();
    _phases = WorkshopData.getAllPhases();

    for (final phase in _phases) {
      int completed = 0;
      for (final module in phase.modules) {
        int moduleCompleted = 0;
        for (final exercise in module.exercises) {
          exercise.isCompleted = completedIds.contains(exercise.id);
          if (exercise.isCompleted) {
            moduleCompleted++;
            completed++;
          }
        }
        module.completedCount = moduleCompleted;
      }
      phase.completedExercises = completed;
    }

    // Unlock phases based on total exercises completed
    _updatePhaseUnlocks();

    // Update favorite state on prompts
    for (final prompt in _prompts) {
      prompt.isFavorited = _favoritedPromptIds.contains(prompt.id);
    }

    _isLoading = false;
    notifyListeners();
  }

  void _updatePhaseUnlocks() {
    final totalCompleted = _progress.totalExercisesCompleted;
    for (int i = 0; i < _phases.length; i++) {
      _phases[i].isUnlocked = i == 0 || totalCompleted >= AppConstants.phaseUnlockRequirements[i];
    }
  }

  // ==================== EXERCISE COMPLETION ====================

  Future<void> markExerciseCompleted(String exerciseId, int phaseId) async {
    // Find and update the exercise
    for (final phase in _phases) {
      for (final module in phase.modules) {
        for (final exercise in module.exercises) {
          if (exercise.id == exerciseId && !exercise.isCompleted) {
            exercise.isCompleted = true;
            exercise.completedAt = DateTime.now();
            module.completedCount++;
            phase.completedExercises++;

            await _db.markExerciseCompleted(exerciseId);
            _progress.totalExercisesCompleted++;
            _progress.completedExerciseIds = [..._progress.completedExerciseIds, exerciseId];

            // Update streak
            _updateStreak();

            // Update phase unlocks
            _updatePhaseUnlocks();

            await _db.saveProgress(_progress);
            notifyListeners();
            return;
          }
        }
      }
    }
  }

  void _updateStreak() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    if (_progress.lastWritingDate == null) {
      _progress.currentStreak = 1;
    } else {
      final last = _progress.lastWritingDate!;
      final lastDay = DateTime(last.year, last.month, last.day);
      final diff = today.difference(lastDay).inDays;

      if (diff == 0) {
        // Same day, streak unchanged
      } else if (diff == 1) {
        // Consecutive day
        _progress.currentStreak++;
      } else {
        // Streak broken
        _progress.currentStreak = 1;
      }
    }

    _progress.lastWritingDate = now;
    if (_progress.currentStreak > _progress.bestStreak) {
      _progress.bestStreak = _progress.currentStreak;
    }
  }

  // ==================== WRITING ENTRIES ====================

  Future<WritingEntry> createWritingEntry({
    String? exerciseId,
    String? exerciseTitle,
    int phaseId = 1,
  }) async {
    final entry = WritingEntry(
      id: _uuid.v4(),
      title: "Untitled",
      content: "",
      exerciseId: exerciseId,
      exerciseTitle: exerciseTitle,
      phaseId: phaseId,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    await _db.saveWritingEntry(entry);
    _writingEntries.insert(0, entry);
    notifyListeners();
    return entry;
  }

  Future<void> saveWritingEntry(WritingEntry entry) async {
    entry.updatedAt = DateTime.now();
    entry.wordCount = _countWords(entry.content);

    // Update streak and word count
    _updateStreak();
    _progress.totalWordsWritten += entry.wordCount;
    _progress.totalSessions++;

    await _db.saveWritingEntry(entry);
    await _db.saveProgress(_progress);

    // Update in memory list
    final idx = _writingEntries.indexWhere((e) => e.id == entry.id);
    if (idx >= 0) {
      _writingEntries[idx] = entry;
    } else {
      _writingEntries.insert(0, entry);
    }

    notifyListeners();
  }

  int _countWords(String text) {
    if (text.trim().isEmpty) return 0;
    return text.trim().split(RegExp(r'\s+')).length;
  }

  Future<void> deleteWritingEntry(String id) async {
    await _db.deleteWritingEntry(id);
    _writingEntries.removeWhere((e) => e.id == id);
    notifyListeners();
  }

  Future<void> importWritingEntry(String title, String content) async {
    final entry = WritingEntry(
      id: _uuid.v4(),
      title: title,
      content: content,
      phaseId: _progress.currentPhase,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
      wordCount: _countWords(content),
      tags: ['imported'],
    );
    await _db.saveWritingEntry(entry);
    _writingEntries.insert(0, entry);
    notifyListeners();
  }

  // ==================== PROMPTS ====================

  Future<void> toggleFavoritePrompt(String promptId) async {
    await _db.toggleFavoritePrompt(promptId);
    final prompt = _prompts.firstWhere((p) => p.id == promptId);
    prompt.isFavorited = !prompt.isFavorited;
    if (prompt.isFavorited) {
      _favoritedPromptIds.add(promptId);
    } else {
      _favoritedPromptIds.remove(promptId);
    }
    notifyListeners();
  }

  List<WritingPrompt> getPromptsByCategory(PromptCategory? category) {
    if (category == null) return _prompts;
    return _prompts.where((p) => p.category == category).toList();
  }

  List<WritingPrompt> getFavoritedPrompts() {
    return _prompts.where((p) => p.isFavorited).toList();
  }

  // ==================== ANALYTICS ====================

  Future<Map<String, int>> getWordCountsForDays(int days) async {
    return await _db.getDailyWordCounts(days);
  }

  int getCompletedExercisesForPhase(int phaseId) {
    final phase = _phases.firstWhere((p) => p.id == phaseId, orElse: () => _phases.first);
    return phase.completedExercises;
  }

  double getOverallProgress() {
    int total = 0;
    int completed = 0;
    for (final phase in _phases) {
      if (phase.isUnlocked) {
        total += phase.totalExercises;
        completed += phase.completedExercises;
      }
    }
    return total > 0 ? completed / total : 0;
  }
}
