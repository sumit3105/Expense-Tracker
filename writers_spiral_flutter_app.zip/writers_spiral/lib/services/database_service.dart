import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/models.dart';
import '../utils/app_theme.dart';

class DatabaseService {
  static Database? _database;
  static final DatabaseService _instance = DatabaseService._internal();
  factory DatabaseService() => _instance;
  DatabaseService._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, AppConstants.dbName);
    return openDatabase(
      path,
      version: 1,
      onCreate: _createTables,
    );
  }

  Future<void> _createTables(Database db, int version) async {
    await db.execute('''
      CREATE TABLE writing_entries (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        exerciseId TEXT,
        exerciseTitle TEXT,
        phaseId INTEGER DEFAULT 1,
        createdAt TEXT NOT NULL,
        updatedAt TEXT NOT NULL,
        wordCount INTEGER DEFAULT 0,
        tags TEXT DEFAULT '[]'
      )
    ''');

    await db.execute('''
      CREATE TABLE user_progress (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE completed_exercises (
        id TEXT PRIMARY KEY,
        completedAt TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE favorited_prompts (
        id TEXT PRIMARY KEY
      )
    ''');
  }

  // ==================== WRITING ENTRIES ====================

  Future<void> saveWritingEntry(WritingEntry entry) async {
    final db = await database;
    await db.insert(
      'writing_entries',
      entry.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<WritingEntry>> getAllWritingEntries() async {
    final db = await database;
    final maps = await db.query('writing_entries', orderBy: 'updatedAt DESC');
    return maps.map((m) => WritingEntry.fromMap(m)).toList();
  }

  Future<List<WritingEntry>> getEntriesForPhase(int phaseId) async {
    final db = await database;
    final maps = await db.query(
      'writing_entries',
      where: 'phaseId = ?',
      whereArgs: [phaseId],
      orderBy: 'updatedAt DESC',
    );
    return maps.map((m) => WritingEntry.fromMap(m)).toList();
  }

  Future<void> deleteWritingEntry(String id) async {
    final db = await database;
    await db.delete('writing_entries', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> getTotalWordCount() async {
    final db = await database;
    final result = await db.rawQuery('SELECT SUM(wordCount) as total FROM writing_entries');
    return (result.first['total'] as int?) ?? 0;
  }

  Future<Map<String, int>> getDailyWordCounts(int days) async {
    final db = await database;
    final since = DateTime.now().subtract(Duration(days: days)).toIso8601String();
    final results = await db.rawQuery('''
      SELECT DATE(createdAt) as day, SUM(wordCount) as total
      FROM writing_entries
      WHERE createdAt >= ?
      GROUP BY DATE(createdAt)
      ORDER BY day ASC
    ''', [since]);

    return {for (var r in results) r['day'] as String: (r['total'] as int?) ?? 0};
  }

  // ==================== PROGRESS ====================

  Future<UserProgress> getProgress() async {
    final db = await database;
    final maps = await db.query('user_progress');
    if (maps.isEmpty) return UserProgress();
    final map = {for (var m in maps) m['key'] as String: m['value'] as String};
    return UserProgress.fromMap({
      'totalExercisesCompleted': int.tryParse(map['totalExercisesCompleted'] ?? '0') ?? 0,
      'currentStreak': int.tryParse(map['currentStreak'] ?? '0') ?? 0,
      'bestStreak': int.tryParse(map['bestStreak'] ?? '0') ?? 0,
      'lastWritingDate': map['lastWritingDate'],
      'totalWordsWritten': int.tryParse(map['totalWordsWritten'] ?? '0') ?? 0,
      'currentPhase': int.tryParse(map['currentPhase'] ?? '1') ?? 1,
      'completedExerciseIds': map['completedExerciseIds'] ?? '[]',
      'dailyWordCounts': map['dailyWordCounts'] ?? '{}',
      'totalSessions': int.tryParse(map['totalSessions'] ?? '0') ?? 0,
      'totalMinutesWritten': int.tryParse(map['totalMinutesWritten'] ?? '0') ?? 0,
    });
  }

  Future<void> saveProgress(UserProgress progress) async {
    final db = await database;
    final m = progress.toMap();
    for (final entry in m.entries) {
      await db.insert(
        'user_progress',
        {'key': entry.key, 'value': entry.value?.toString() ?? ''},
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
  }

  Future<void> markExerciseCompleted(String exerciseId) async {
    final db = await database;
    await db.insert(
      'completed_exercises',
      {'id': exerciseId, 'completedAt': DateTime.now().toIso8601String()},
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
  }

  Future<List<String>> getCompletedExerciseIds() async {
    final db = await database;
    final maps = await db.query('completed_exercises');
    return maps.map((m) => m['id'] as String).toList();
  }

  Future<void> toggleFavoritePrompt(String promptId) async {
    final db = await database;
    final existing = await db.query('favorited_prompts', where: 'id = ?', whereArgs: [promptId]);
    if (existing.isEmpty) {
      await db.insert('favorited_prompts', {'id': promptId});
    } else {
      await db.delete('favorited_prompts', where: 'id = ?', whereArgs: [promptId]);
    }
  }

  Future<List<String>> getFavoritedPromptIds() async {
    final db = await database;
    final maps = await db.query('favorited_prompts');
    return maps.map((m) => m['id'] as String).toList();
  }
}
