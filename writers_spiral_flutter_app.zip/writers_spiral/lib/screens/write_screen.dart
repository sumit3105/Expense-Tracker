import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/models.dart';
import '../services/app_state.dart';
import '../utils/app_theme.dart';

class WriteScreen extends StatefulWidget {
  final WritingEntry? entry;
  final String? prompt;
  final String? exerciseTitle;
  final VoidCallback? onComplete;

  const WriteScreen({super.key, this.entry, this.prompt, this.exerciseTitle, this.onComplete});

  @override
  State<WriteScreen> createState() => _WriteScreenState();
}

class _WriteScreenState extends State<WriteScreen> {
  late TextEditingController _titleController;
  late TextEditingController _contentController;
  WritingEntry? _entry;
  Timer? _autoSaveTimer;
  bool _isSaving = false;
  bool _hasUnsavedChanges = false;
  int _wordCount = 0;
  DateTime? _sessionStart;
  bool _focusMode = false;
  bool _showPrompt = true;

  @override
  void initState() {
    super.initState();
    _entry = widget.entry;
    _titleController = TextEditingController(text: _entry?.title ?? "");
    _contentController = TextEditingController(text: _entry?.content ?? "");
    _wordCount = _countWords(_contentController.text);
    _sessionStart = DateTime.now();

    _contentController.addListener(_onTextChanged);
    _titleController.addListener(_onTextChanged);
  }

  @override
  void dispose() {
    _autoSaveTimer?.cancel();
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  void _onTextChanged() {
    setState(() {
      _wordCount = _countWords(_contentController.text);
      _hasUnsavedChanges = true;
    });
    _scheduleAutoSave();
  }

  void _scheduleAutoSave() {
    _autoSaveTimer?.cancel();
    _autoSaveTimer = Timer(const Duration(seconds: 3), _autoSave);
  }

  Future<void> _autoSave() async {
    if (!_hasUnsavedChanges) return;
    await _save();
  }

  Future<void> _save() async {
    if (_isSaving) return;
    setState(() => _isSaving = true);

    final state = context.read<AppState>();

    if (_entry == null) {
      _entry = await state.createWritingEntry(phaseId: 1);
    }

    _entry!.title = _titleController.text.isEmpty ? "Untitled" : _titleController.text;
    _entry!.content = _contentController.text;
    _entry!.wordCount = _wordCount;

    await state.saveWritingEntry(_entry!);

    setState(() {
      _isSaving = false;
      _hasUnsavedChanges = false;
    });
  }

  int _countWords(String text) {
    if (text.trim().isEmpty) return 0;
    return text.trim().split(RegExp(r'\s+')).length;
  }

  String get _sessionDuration {
    if (_sessionStart == null) return "0m";
    final elapsed = DateTime.now().difference(_sessionStart!).inMinutes;
    return "${elapsed}m";
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (_hasUnsavedChanges) await _save();
        return true;
      },
      child: Scaffold(
        backgroundColor: AppTheme.bgDeep,
        appBar: _focusMode ? null : _buildAppBar(),
        body: Column(
          children: [
            if (_focusMode) _buildFocusModeBar(),
            if (widget.prompt != null && _showPrompt && !_focusMode)
              _buildPromptBanner(),
            _buildWordCountBar(),
            Expanded(child: _buildEditor()),
          ],
        ),
        floatingActionButton: _focusMode ? null : _buildFAB(),
      ),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: AppTheme.bgDeep,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios, size: 18),
        onPressed: () async {
          if (_hasUnsavedChanges) await _save();
          if (mounted) Navigator.pop(context);
        },
      ),
      title: widget.exerciseTitle != null
          ? Text(widget.exerciseTitle!, style: const TextStyle(fontSize: 16))
          : const Text("Writing"),
      actions: [
        // Focus mode
        IconButton(
          icon: Icon(Icons.fullscreen, color: AppTheme.textSecondary),
          onPressed: () => setState(() => _focusMode = true),
          tooltip: "Focus Mode",
        ),
        // Save indicator
        Container(
          margin: const EdgeInsets.only(right: 8),
          child: _isSaving
              ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.goldPrimary))
              : Icon(
                  _hasUnsavedChanges ? Icons.circle : Icons.check_circle,
                  color: _hasUnsavedChanges ? AppTheme.textMuted : AppTheme.emerald,
                  size: 18,
                ),
        ),
        if (widget.onComplete != null)
          TextButton(
            onPressed: () async {
              await _save();
              widget.onComplete?.call();
            },
            child: const Text("Done", style: TextStyle(color: AppTheme.goldPrimary, fontFamily: 'SourceSerif4', fontWeight: FontWeight.w700)),
          ),
      ],
    );
  }

  Widget _buildFocusModeBar() {
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 8,
        left: 16,
        right: 16,
        bottom: 8,
      ),
      color: AppTheme.bgDeep,
      child: Row(
        children: [
          GestureDetector(
            onTap: () async {
              if (_hasUnsavedChanges) await _save();
              setState(() => _focusMode = false);
            },
            child: const Icon(Icons.fullscreen_exit, color: AppTheme.textMuted, size: 20),
          ),
          const Spacer(),
          Text("$_wordCount words", style: const TextStyle(
            fontFamily: 'SourceCodePro',
            fontSize: 11,
            color: AppTheme.textMuted,
          )),
          const SizedBox(width: 16),
          Text(_sessionDuration, style: const TextStyle(
            fontFamily: 'SourceCodePro',
            fontSize: 11,
            color: AppTheme.textMuted,
          )),
        ],
      ),
    );
  }

  Widget _buildPromptBanner() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.violet.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.violet.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          const Icon(Icons.format_quote, color: AppTheme.violet, size: 16),
          const SizedBox(width: 10),
          Expanded(
            child: Text(widget.prompt!, style: const TextStyle(
              fontFamily: 'CrimsonText',
              fontSize: 15,
              color: AppTheme.textSecondary,
              fontStyle: FontStyle.italic,
              height: 1.4,
            )),
          ),
          GestureDetector(
            onTap: () => setState(() => _showPrompt = false),
            child: const Icon(Icons.close, color: AppTheme.textMuted, size: 16),
          ),
        ],
      ),
    );
  }

  Widget _buildWordCountBar() {
    if (_focusMode) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
      child: Row(
        children: [
          Text(
            "$_wordCount words",
            style: const TextStyle(
              fontFamily: 'SourceCodePro',
              fontSize: 11,
              color: AppTheme.textMuted,
            ),
          ),
          const SizedBox(width: 12),
          Text(
            "Session: $_sessionDuration",
            style: const TextStyle(
              fontFamily: 'SourceCodePro',
              fontSize: 11,
              color: AppTheme.textMuted,
            ),
          ),
          const Spacer(),
          if (_hasUnsavedChanges)
            const Text("Saving...", style: TextStyle(
              fontFamily: 'SourceCodePro',
              fontSize: 10,
              color: AppTheme.textMuted,
            )),
        ],
      ),
    );
  }

  Widget _buildEditor() {
    return SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(
        _focusMode ? 24 : 20,
        16,
        _focusMode ? 24 : 20,
        100,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title
          TextField(
            controller: _titleController,
            style: TextStyle(
              fontFamily: 'PlayfairDisplay',
              fontSize: _focusMode ? 28 : 24,
              color: AppTheme.textPrimary,
              fontWeight: FontWeight.w700,
              height: 1.3,
            ),
            decoration: InputDecoration(
              hintText: "Title your piece...",
              hintStyle: TextStyle(
                fontFamily: 'PlayfairDisplay',
                fontSize: _focusMode ? 28 : 24,
                color: AppTheme.textMuted,
                fontWeight: FontWeight.w700,
              ),
              border: InputBorder.none,
              contentPadding: EdgeInsets.zero,
            ),
            maxLines: null,
            textCapitalization: TextCapitalization.words,
          ),
          const SizedBox(height: 4),
          Container(height: 1, color: AppTheme.borderColor),
          const SizedBox(height: 16),
          // Content
          TextField(
            controller: _contentController,
            style: TextStyle(
              fontFamily: 'CrimsonText',
              fontSize: _focusMode ? 20 : 18,
              color: AppTheme.textPrimary,
              height: 1.8,
            ),
            decoration: InputDecoration(
              hintText: "Begin writing here. Don't stop. Don't edit. Just write...",
              hintStyle: TextStyle(
                fontFamily: 'CrimsonText',
                fontSize: _focusMode ? 20 : 18,
                color: AppTheme.textMuted,
                fontStyle: FontStyle.italic,
                height: 1.8,
              ),
              border: InputBorder.none,
              contentPadding: EdgeInsets.zero,
            ),
            maxLines: null,
            autofocus: true,
            keyboardType: TextInputType.multiline,
            textCapitalization: TextCapitalization.sentences,
          ),
        ],
      ),
    );
  }

  Widget _buildFAB() {
    if (widget.onComplete == null) return const SizedBox.shrink();
    return FloatingActionButton.extended(
      onPressed: () async {
        await _save();
        widget.onComplete?.call();
      },
      backgroundColor: AppTheme.goldPrimary,
      label: const Text("Complete Exercise", style: TextStyle(
        color: AppTheme.bgDeep,
        fontFamily: 'SourceSerif4',
        fontWeight: FontWeight.w700,
      )),
      icon: const Icon(Icons.check, color: AppTheme.bgDeep),
    );
  }
}
