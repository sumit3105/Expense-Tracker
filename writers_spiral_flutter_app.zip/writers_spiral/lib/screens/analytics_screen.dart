import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../services/app_state.dart';
import '../models/models.dart';
import '../utils/app_theme.dart';

class AnalyticsScreen extends StatefulWidget {
  const AnalyticsScreen({super.key});

  @override
  State<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends State<AnalyticsScreen> {
  Map<String, int> _wordCounts = {};
  bool _loadingCharts = true;

  @override
  void initState() {
    super.initState();
    _loadChartData();
  }

  Future<void> _loadChartData() async {
    final state = context.read<AppState>();
    final counts = await state.getWordCountsForDays(30);
    setState(() {
      _wordCounts = counts;
      _loadingCharts = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(
      builder: (context, state, _) {
        return Scaffold(
          backgroundColor: AppTheme.bgDeep,
          appBar: AppBar(
            backgroundColor: AppTheme.bgDeep,
            title: const Text("Your Journey"),
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
            children: [
              _buildHeroStats(state),
              const SizedBox(height: 24),
              _buildStreakCard(state),
              const SizedBox(height: 24),
              _buildWordCountChart(),
              const SizedBox(height: 24),
              _buildPhaseProgress(state),
              const SizedBox(height: 24),
              _buildWritingCalendar(state),
              const SizedBox(height: 24),
              _buildJourneyTimeline(state),
            ],
          ),
        );
      },
    );
  }

  Widget _buildHeroStats(AppState state) {
    final progress = state.progress;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.goldPrimary.withOpacity(0.15),
            AppTheme.goldDim.withOpacity(0.05),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.goldPrimary.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("Your Writing Life", style: TextStyle(
            fontFamily: 'PlayfairDisplay',
            fontSize: 20,
            color: AppTheme.goldPrimary,
            fontWeight: FontWeight.w700,
          )),
          const SizedBox(height: 16),
          Row(
            children: [
              _BigStat(value: "${progress.totalExercisesCompleted}", label: "Exercises\nCompleted", color: AppTheme.goldPrimary),
              _BigStat(value: "${progress.totalWordsWritten}", label: "Total\nWords", color: AppTheme.inkBlue),
              _BigStat(value: "${progress.totalSessions}", label: "Writing\nSessions", color: AppTheme.emerald),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStreakCard(AppState state) {
    final progress = state.progress;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.local_fire_department, color: AppTheme.goldPrimary, size: 20),
              const SizedBox(width: 8),
              const Text("Streak", style: TextStyle(
                fontFamily: 'PlayfairDisplay',
                fontSize: 18,
                color: AppTheme.textPrimary,
                fontWeight: FontWeight.w600,
              )),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppTheme.goldPrimary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppTheme.goldPrimary.withOpacity(0.3)),
                  ),
                  child: Column(
                    children: [
                      Text("${progress.currentStreak}", style: const TextStyle(
                        fontFamily: 'PlayfairDisplay',
                        fontSize: 40,
                        color: AppTheme.goldPrimary,
                        fontWeight: FontWeight.w800,
                      )),
                      const Text("Current", style: TextStyle(
                        fontFamily: 'SourceCodePro',
                        fontSize: 11,
                        color: AppTheme.textMuted,
                        letterSpacing: 0.8,
                      )),
                      const Text("streak", style: TextStyle(
                        fontFamily: 'SourceCodePro',
                        fontSize: 11,
                        color: AppTheme.textMuted,
                      )),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppTheme.goldDim.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppTheme.goldDim.withOpacity(0.3)),
                  ),
                  child: Column(
                    children: [
                      const Icon(Icons.emoji_events, color: AppTheme.goldLight, size: 20),
                      const SizedBox(height: 4),
                      Text("${progress.bestStreak}", style: const TextStyle(
                        fontFamily: 'PlayfairDisplay',
                        fontSize: 40,
                        color: AppTheme.goldLight,
                        fontWeight: FontWeight.w800,
                      )),
                      const Text("Best ever", style: TextStyle(
                        fontFamily: 'SourceCodePro',
                        fontSize: 11,
                        color: AppTheme.textMuted,
                      )),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.bgElevated,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Icon(
                  progress.wroteToday ? Icons.check_circle : Icons.radio_button_unchecked,
                  color: progress.wroteToday ? AppTheme.emerald : AppTheme.textMuted,
                  size: 18,
                ),
                const SizedBox(width: 10),
                Text(
                  progress.wroteToday
                      ? "You wrote today. The streak continues."
                      : "Write today to keep the streak alive.",
                  style: TextStyle(
                    fontFamily: 'CrimsonText',
                    fontSize: 14,
                    color: progress.wroteToday ? AppTheme.emerald : AppTheme.textMuted,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWordCountChart() {
    if (_loadingCharts) {
      return const Center(child: CircularProgressIndicator(color: AppTheme.goldPrimary));
    }

    // Build last 14 days
    final now = DateTime.now();
    final bars = <BarChartGroupData>[];
    double maxY = 100;

    for (int i = 13; i >= 0; i--) {
      final day = now.subtract(Duration(days: i));
      final key = DateFormat('yyyy-MM-dd').format(day);
      final count = (_wordCounts[key] ?? 0).toDouble();
      if (count > maxY) maxY = count;
      bars.add(BarChartGroupData(
        x: 13 - i,
        barRods: [BarChartRodData(
          toY: count,
          color: count > 0 ? AppTheme.inkBlue : AppTheme.borderColor,
          width: 12,
          borderRadius: BorderRadius.circular(4),
        )],
      ));
    }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.bar_chart, color: AppTheme.inkBlue, size: 18),
              SizedBox(width: 8),
              Text("Words Written — Last 14 Days", style: TextStyle(
                fontFamily: 'PlayfairDisplay',
                fontSize: 16,
                color: AppTheme.textPrimary,
                fontWeight: FontWeight.w600,
              )),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 160,
            child: BarChart(
              BarChartData(
                maxY: maxY * 1.2,
                barGroups: bars,
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: maxY / 4,
                  getDrawingHorizontalLine: (v) => FlLine(color: AppTheme.borderColor, strokeWidth: 1),
                ),
                borderData: FlBorderData(show: false),
                titlesData: FlTitlesData(
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      interval: 2,
                      getTitlesWidget: (value, meta) {
                        final day = now.subtract(Duration(days: 13 - value.toInt()));
                        return Text(DateFormat('d').format(day), style: const TextStyle(
                          fontFamily: 'SourceCodePro',
                          fontSize: 9,
                          color: AppTheme.textMuted,
                        ));
                      },
                    ),
                  ),
                  leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                ),
                barTouchData: BarTouchData(
                  touchTooltipData: BarTouchTooltipData(
                    getTooltipItem: (group, groupIndex, rod, rodIndex) {
                      return BarTooltipItem(
                        "${rod.toY.toInt()} words",
                        const TextStyle(fontFamily: 'SourceCodePro', fontSize: 11, color: AppTheme.textPrimary),
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPhaseProgress(AppState state) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("Phase Progress", style: TextStyle(
            fontFamily: 'PlayfairDisplay',
            fontSize: 18,
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w600,
          )),
          const SizedBox(height: 16),
          ...state.phases.asMap().entries.map((entry) {
            final phase = entry.value;
            final color = AppTheme.phaseColors[entry.key];

            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      if (!phase.isUnlocked)
                        const Icon(Icons.lock, size: 12, color: AppTheme.textMuted),
                      if (phase.isUnlocked)
                        Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
                      const SizedBox(width: 8),
                      Text(
                        "Phase ${phase.id}: ${phase.name}",
                        style: TextStyle(
                          fontFamily: 'SourceSerif4',
                          fontSize: 14,
                          color: phase.isUnlocked ? AppTheme.textPrimary : AppTheme.textMuted,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        phase.isUnlocked ? "${phase.completedExercises}/${phase.totalExercises}" : "Locked",
                        style: TextStyle(
                          fontFamily: 'SourceCodePro',
                          fontSize: 10,
                          color: phase.isUnlocked ? color : AppTheme.textMuted,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: phase.isUnlocked ? phase.progressPercent : 0,
                      backgroundColor: color.withOpacity(0.1),
                      valueColor: AlwaysStoppedAnimation<Color>(
                        phase.isUnlocked ? color : AppTheme.borderColor,
                      ),
                      minHeight: 6,
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildWritingCalendar(AppState state) {
    final now = DateTime.now();
    final entries = state.writingEntries;
    final writtenDays = <String>{};

    for (final e in entries) {
      writtenDays.add(DateFormat('yyyy-MM-dd').format(e.createdAt));
    }

    // Build last 35 days (5 weeks)
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("Writing Days", style: TextStyle(
            fontFamily: 'PlayfairDisplay',
            fontSize: 18,
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w600,
          )),
          const SizedBox(height: 16),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: List.generate(35, (i) {
              final day = now.subtract(Duration(days: 34 - i));
              final key = DateFormat('yyyy-MM-dd').format(day);
              final wrote = writtenDays.contains(key);
              final isToday = key == DateFormat('yyyy-MM-dd').format(now);

              return Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: wrote
                      ? AppTheme.goldPrimary.withOpacity(0.8)
                      : AppTheme.bgElevated,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color: isToday ? AppTheme.goldPrimary : Colors.transparent,
                    width: 2,
                  ),
                ),
                child: Center(
                  child: Text(
                    DateFormat('d').format(day),
                    style: TextStyle(
                      fontFamily: 'SourceCodePro',
                      fontSize: 9,
                      color: wrote ? AppTheme.bgDeep : AppTheme.textMuted,
                      fontWeight: wrote ? FontWeight.w700 : FontWeight.normal,
                    ),
                  ),
                ),
              );
            }),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Container(width: 12, height: 12, decoration: BoxDecoration(color: AppTheme.goldPrimary, borderRadius: BorderRadius.circular(3))),
              const SizedBox(width: 6),
              const Text("Wrote this day", style: TextStyle(fontFamily: 'SourceCodePro', fontSize: 10, color: AppTheme.textMuted)),
              const SizedBox(width: 16),
              Container(width: 12, height: 12, decoration: BoxDecoration(color: AppTheme.bgElevated, borderRadius: BorderRadius.circular(3), border: Border.all(color: AppTheme.borderColor))),
              const SizedBox(width: 6),
              const Text("No writing", style: TextStyle(fontFamily: 'SourceCodePro', fontSize: 10, color: AppTheme.textMuted)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildJourneyTimeline(AppState state) {
    final unlockedPhases = state.phases.where((p) => p.isUnlocked).toList();

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("The Spiral Journey", style: TextStyle(
            fontFamily: 'PlayfairDisplay',
            fontSize: 18,
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w600,
          )),
          const SizedBox(height: 4),
          const Text("Your path through the phases", style: TextStyle(
            fontFamily: 'CrimsonText',
            fontSize: 14,
            color: AppTheme.textMuted,
            fontStyle: FontStyle.italic,
          )),
          const SizedBox(height: 20),
          ...unlockedPhases.asMap().entries.map((entry) {
            final phase = entry.value;
            final color = AppTheme.phaseColors[(phase.id - 1).clamp(0, 5)];
            final isLast = entry.key == unlockedPhases.length - 1;

            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  children: [
                    Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: phase.isComplete ? color : color.withOpacity(0.2),
                        shape: BoxShape.circle,
                        border: Border.all(color: color, width: 2),
                      ),
                      child: Icon(
                        phase.isComplete ? Icons.check : Icons.radio_button_unchecked,
                        color: phase.isComplete ? AppTheme.bgDeep : color,
                        size: 16,
                      ),
                    ),
                    if (!isLast)
                      Container(width: 2, height: 40, color: color.withOpacity(0.3)),
                  ],
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Phase ${phase.id}: ${phase.name}", style: TextStyle(
                          fontFamily: 'SourceSerif4',
                          fontSize: 15,
                          color: AppTheme.textPrimary,
                          fontWeight: FontWeight.w600,
                        )),
                        Text(phase.subtitle, style: TextStyle(
                          fontFamily: 'CrimsonText',
                          fontSize: 13,
                          color: color.withOpacity(0.8),
                          fontStyle: FontStyle.italic,
                        )),
                        Text("${phase.completedExercises} / ${phase.totalExercises} exercises", style: const TextStyle(
                          fontFamily: 'SourceCodePro',
                          fontSize: 10,
                          color: AppTheme.textMuted,
                        )),
                        if (!isLast) const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ],
            );
          }),
          if (state.phases.any((p) => !p.isUnlocked)) ...[
            Row(
              children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: AppTheme.locked,
                    shape: BoxShape.circle,
                    border: Border.all(color: AppTheme.borderColor),
                  ),
                  child: const Icon(Icons.lock, color: AppTheme.textMuted, size: 14),
                ),
                const SizedBox(width: 16),
                const Text("More phases await...", style: TextStyle(
                  fontFamily: 'CrimsonText',
                  fontSize: 15,
                  color: AppTheme.textMuted,
                  fontStyle: FontStyle.italic,
                )),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class _BigStat extends StatelessWidget {
  final String value, label;
  final Color color;

  const _BigStat({required this.value, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Text(value, style: TextStyle(
            fontFamily: 'PlayfairDisplay',
            fontSize: 28,
            color: color,
            fontWeight: FontWeight.w800,
          )),
          Text(label, style: const TextStyle(
            fontFamily: 'SourceCodePro',
            fontSize: 9,
            color: AppTheme.textMuted,
            letterSpacing: 0.3,
          ), textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
