import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../services/ai_service.dart';
import '../models/models.dart';
import '../utils/app_theme.dart';
import 'write_screen.dart';

class PromptScreen extends StatefulWidget {
  const PromptScreen({super.key});

  @override
  State<PromptScreen> createState() => _PromptScreenState();
}

class _PromptScreenState extends State<PromptScreen> {
  PromptCategory? _selectedCategory;
  bool _favoritesOnly = false;
  bool _generatingAI = false;
  String? _aiPrompt;

  static const Map<PromptCategory, String> _categoryNames = {
    PromptCategory.character: "Character",
    PromptCategory.scene: "Scene",
    PromptCategory.situation: "Situation",
    PromptCategory.title: "Title",
    PromptCategory.object: "Object",
    PromptCategory.dialogue: "Dialogue",
    PromptCategory.rewrite: "Rewrite",
    PromptCategory.adaptation: "Adaptation",
  };

  static const Map<PromptCategory, Color> _categoryColors = {
    PromptCategory.character: AppTheme.goldPrimary,
    PromptCategory.scene: AppTheme.inkBlue,
    PromptCategory.situation: AppTheme.emerald,
    PromptCategory.title: AppTheme.violet,
    PromptCategory.object: AppTheme.crimson,
    PromptCategory.dialogue: Color(0xFFE07B40),
    PromptCategory.rewrite: Color(0xFF7EC8D4),
    PromptCategory.adaptation: Color(0xFFB07EE4),
  };

  Future<void> _generateAIPrompt(AppState state) async {
    setState(() {
      _generatingAI = true;
      _aiPrompt = null;
    });

    final prompt = await AIService.generatePrompt(
      category: _selectedCategory ?? PromptCategory.scene,
      phaseId: state.progress.currentPhase,
    );

    setState(() {
      _generatingAI = false;
      _aiPrompt = prompt ?? "Could not generate prompt. Check your API key in Settings.";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(
      builder: (context, state, _) {
        var prompts = _favoritesOnly
            ? state.getFavoritedPrompts()
            : state.getPromptsByCategory(_selectedCategory);

        return Scaffold(
          backgroundColor: AppTheme.bgDeep,
          appBar: AppBar(
            backgroundColor: AppTheme.bgDeep,
            title: const Text("Prompt Bank"),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios, size: 18),
              onPressed: () => Navigator.pop(context),
            ),
            actions: [
              IconButton(
                icon: Icon(
                  _favoritesOnly ? Icons.favorite : Icons.favorite_border,
                  color: _favoritesOnly ? AppTheme.crimson : AppTheme.textMuted,
                ),
                onPressed: () => setState(() => _favoritesOnly = !_favoritesOnly),
              ),
            ],
          ),
          body: Column(
            children: [
              // AI Prompt Generator
              _buildAIGenerator(state),
              // Category filters
              _buildCategoryFilter(),
              // Prompt list
              Expanded(
                child: prompts.isEmpty
                    ? _buildEmpty()
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                        itemCount: prompts.length,
                        itemBuilder: (ctx, i) => _PromptCard(
                          prompt: prompts[i],
                          onFavorite: () => state.toggleFavoritePrompt(prompts[i].id),
                          onWrite: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => WriteScreen(prompt: prompts[i].text)),
                          ),
                          color: _categoryColors[prompts[i].category] ?? AppTheme.goldPrimary,
                        ),
                      ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildAIGenerator(AppState state) {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [AppTheme.violet.withOpacity(0.15), AppTheme.inkBlue.withOpacity(0.08)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.violet.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.auto_awesome, color: AppTheme.violet, size: 16),
              const SizedBox(width: 8),
              const Text("AI Prompt Generator", style: TextStyle(
                fontFamily: 'SourceCodePro',
                fontSize: 12,
                color: AppTheme.violet,
                letterSpacing: 0.8,
              )),
              const Spacer(),
              GestureDetector(
                onTap: _generatingAI ? null : () => _generateAIPrompt(state),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppTheme.violet.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AppTheme.violet.withOpacity(0.4)),
                  ),
                  child: _generatingAI
                      ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.violet))
                      : const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.refresh, size: 12, color: AppTheme.violet),
                            SizedBox(width: 4),
                            Text("Generate", style: TextStyle(fontFamily: 'SourceCodePro', fontSize: 11, color: AppTheme.violet)),
                          ],
                        ),
                ),
              ),
            ],
          ),
          if (_aiPrompt != null) ...[
            const SizedBox(height: 12),
            Text(_aiPrompt!, style: const TextStyle(
              fontFamily: 'CrimsonText',
              fontSize: 17,
              color: AppTheme.textPrimary,
              height: 1.5,
              fontStyle: FontStyle.italic,
            )),
            const SizedBox(height: 10),
            GestureDetector(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => WriteScreen(prompt: _aiPrompt!)),
              ),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: AppTheme.violet.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppTheme.violet.withOpacity(0.3)),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.edit, size: 14, color: AppTheme.violet),
                    SizedBox(width: 6),
                    Text("Write from this", style: TextStyle(fontFamily: 'SourceCodePro', fontSize: 11, color: AppTheme.violet)),
                  ],
                ),
              ),
            ),
          ] else ...[
            const SizedBox(height: 8),
            const Text("Generate a unique prompt tailored to your current phase.", style: TextStyle(
              fontFamily: 'CrimsonText',
              fontSize: 14,
              color: AppTheme.textMuted,
              fontStyle: FontStyle.italic,
            )),
            const Text("Requires API key (add in settings).", style: TextStyle(
              fontFamily: 'SourceCodePro',
              fontSize: 10,
              color: AppTheme.textMuted,
            )),
          ],
        ],
      ),
    );
  }

  Widget _buildCategoryFilter() {
    return SizedBox(
      height: 44,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        children: [
          _ChipBtn(
            label: "All",
            isSelected: _selectedCategory == null,
            color: AppTheme.goldPrimary,
            onTap: () => setState(() => _selectedCategory = null),
          ),
          ..._categoryNames.entries.map((e) => _ChipBtn(
            label: e.value,
            isSelected: _selectedCategory == e.key,
            color: _categoryColors[e.key] ?? AppTheme.goldPrimary,
            onTap: () => setState(() => _selectedCategory = _selectedCategory == e.key ? null : e.key),
          )),
        ],
      ),
    );
  }

  Widget _buildEmpty() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.favorite_border, color: AppTheme.textMuted, size: 40),
          SizedBox(height: 12),
          Text("No favourited prompts yet", style: TextStyle(
            fontFamily: 'CrimsonText',
            fontSize: 16,
            color: AppTheme.textMuted,
            fontStyle: FontStyle.italic,
          )),
        ],
      ),
    );
  }
}

class _PromptCard extends StatelessWidget {
  final WritingPrompt prompt;
  final VoidCallback onFavorite;
  final VoidCallback onWrite;
  final Color color;

  const _PromptCard({required this.prompt, required this.onFavorite, required this.onWrite, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: prompt.isFavorited ? color.withOpacity(0.4) : AppTheme.borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(prompt.category.name.toUpperCase(), style: TextStyle(
                  fontFamily: 'SourceCodePro',
                  fontSize: 9,
                  color: color,
                  letterSpacing: 1,
                )),
              ),
              if (prompt.isAIGenerated) ...[
                const SizedBox(width: 8),
                const Icon(Icons.auto_awesome, size: 12, color: AppTheme.violet),
              ],
              const Spacer(),
              GestureDetector(
                onTap: onFavorite,
                child: Icon(
                  prompt.isFavorited ? Icons.favorite : Icons.favorite_border,
                  color: prompt.isFavorited ? AppTheme.crimson : AppTheme.textMuted,
                  size: 18,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(prompt.text, style: const TextStyle(
            fontFamily: 'CrimsonText',
            fontSize: 17,
            color: AppTheme.textPrimary,
            height: 1.5,
          )),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: onWrite,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.edit, size: 12, color: color),
                  const SizedBox(width: 6),
                  Text("Write from this", style: TextStyle(
                    fontFamily: 'SourceCodePro',
                    fontSize: 11,
                    color: color,
                    fontWeight: FontWeight.w600,
                  )),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ChipBtn extends StatelessWidget {
  final String label;
  final bool isSelected;
  final Color color;
  final VoidCallback onTap;

  const _ChipBtn({required this.label, required this.isSelected, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? color.withOpacity(0.15) : AppTheme.bgCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: isSelected ? color : AppTheme.borderColor),
        ),
        child: Text(label, style: TextStyle(
          fontFamily: 'SourceCodePro',
          fontSize: 11,
          color: isSelected ? color : AppTheme.textMuted,
          fontWeight: isSelected ? FontWeight.w700 : FontWeight.normal,
        )),
      ),
    );
  }
}
