import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:file_picker/file_picker.dart';
import '../services/app_state.dart';
import '../models/models.dart';
import '../utils/app_theme.dart';
import 'write_screen.dart';

class JournalScreen extends StatefulWidget {
  const JournalScreen({super.key});

  @override
  State<JournalScreen> createState() => _JournalScreenState();
}

class _JournalScreenState extends State<JournalScreen> {
  String _search = "";
  int? _filterPhase;

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(
      builder: (context, state, _) {
        var entries = state.writingEntries;

        // Filter
        if (_search.isNotEmpty) {
          entries = entries.where((e) =>
            e.title.toLowerCase().contains(_search.toLowerCase()) ||
            e.content.toLowerCase().contains(_search.toLowerCase())).toList();
        }
        if (_filterPhase != null) {
          entries = entries.where((e) => e.phaseId == _filterPhase).toList();
        }

        return Scaffold(
          backgroundColor: AppTheme.bgDeep,
          appBar: AppBar(
            backgroundColor: AppTheme.bgDeep,
            title: const Text("Writing Journal"),
            actions: [
              IconButton(
                icon: const Icon(Icons.file_upload_outlined, color: AppTheme.inkBlue),
                onPressed: () => _importFile(context, state),
                tooltip: "Import writing",
              ),
              IconButton(
                icon: const Icon(Icons.add, color: AppTheme.goldPrimary),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const WriteScreen()),
                ),
              ),
            ],
          ),
          body: Column(
            children: [
              _buildSearchBar(),
              _buildPhaseFilter(state),
              Expanded(
                child: entries.isEmpty
                    ? _buildEmpty()
                    : _buildEntryList(context, state, entries),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: TextField(
        onChanged: (v) => setState(() => _search = v),
        style: const TextStyle(fontFamily: 'CrimsonText', fontSize: 16, color: AppTheme.textPrimary),
        decoration: InputDecoration(
          hintText: "Search your writing...",
          hintStyle: const TextStyle(fontFamily: 'CrimsonText', fontSize: 16, color: AppTheme.textMuted),
          prefixIcon: const Icon(Icons.search, color: AppTheme.textMuted, size: 20),
          filled: true,
          fillColor: AppTheme.bgCard,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: AppTheme.borderColor),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: AppTheme.borderColor),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: AppTheme.goldPrimary),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
      ),
    );
  }

  Widget _buildPhaseFilter(AppState state) {
    return SizedBox(
      height: 44,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        children: [
          _FilterChip(label: "All", isSelected: _filterPhase == null, onTap: () => setState(() => _filterPhase = null), color: AppTheme.goldPrimary),
          ...List.generate(6, (i) {
            final phase = i + 1;
            final color = AppTheme.phaseColors[i];
            return _FilterChip(
              label: "P$phase",
              isSelected: _filterPhase == phase,
              onTap: () => setState(() => _filterPhase = _filterPhase == phase ? null : phase),
              color: color,
            );
          }),
          _FilterChip(label: "Imported", isSelected: false, onTap: () {}, color: AppTheme.textMuted),
        ],
      ),
    );
  }

  Widget _buildEntryList(BuildContext context, AppState state, List<WritingEntry> entries) {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
      itemCount: entries.length,
      itemBuilder: (context, i) {
        return _EntryCard(
          entry: entries[i],
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => WriteScreen(entry: entries[i])),
          ),
          onDelete: () => _confirmDelete(context, state, entries[i]),
        );
      },
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.book_outlined, color: AppTheme.textMuted, size: 48),
          const SizedBox(height: 16),
          const Text("Nothing written yet", style: TextStyle(
            fontFamily: 'PlayfairDisplay',
            fontSize: 20,
            color: AppTheme.textSecondary,
          )),
          const SizedBox(height: 8),
          const Text("Start an exercise or write freely.\nEvery word matters.", style: TextStyle(
            fontFamily: 'CrimsonText',
            fontSize: 15,
            color: AppTheme.textMuted,
            fontStyle: FontStyle.italic,
          ), textAlign: TextAlign.center),
          const SizedBox(height: 24),
          GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const WriteScreen())),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              decoration: BoxDecoration(
                color: AppTheme.goldPrimary.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.goldPrimary.withOpacity(0.4)),
              ),
              child: const Text("Write Something", style: TextStyle(
                fontFamily: 'SourceSerif4',
                color: AppTheme.goldPrimary,
                fontWeight: FontWeight.w600,
              )),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _importFile(BuildContext context, AppState state) async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['txt', 'md'],
      );
      if (result != null && result.files.single.bytes != null) {
        final content = String.fromCharCodes(result.files.single.bytes!);
        final name = result.files.single.name.replaceAll(RegExp(r'\.[^.]+$'), '');
        await state.importWritingEntry(name, content);
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Writing imported successfully"), backgroundColor: AppTheme.emerald),
          );
        }
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Could not import file"), backgroundColor: AppTheme.crimson),
        );
      }
    }
  }

  Future<void> _confirmDelete(BuildContext context, AppState state, WritingEntry entry) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.bgCard,
        title: const Text("Delete entry?", style: TextStyle(color: AppTheme.textPrimary, fontFamily: 'PlayfairDisplay')),
        content: Text("'${entry.title}' will be permanently deleted.", style: const TextStyle(color: AppTheme.textSecondary)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text("Cancel")),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text("Delete", style: TextStyle(color: AppTheme.crimson))),
        ],
      ),
    );
    if (confirm == true) {
      await state.deleteWritingEntry(entry.id);
    }
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  final Color color;

  const _FilterChip({required this.label, required this.isSelected, required this.onTap, required this.color});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? color.withOpacity(0.15) : AppTheme.bgCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: isSelected ? color : AppTheme.borderColor),
        ),
        child: Text(label, style: TextStyle(
          fontFamily: 'SourceCodePro',
          fontSize: 11,
          color: isSelected ? color : AppTheme.textMuted,
          fontWeight: isSelected ? FontWeight.w700 : FontWeight.normal,
        )),
      ),
    );
  }
}

class _EntryCard extends StatelessWidget {
  final WritingEntry entry;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const _EntryCard({required this.entry, required this.onTap, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final phaseColor = AppTheme.phaseColors[(entry.phaseId - 1).clamp(0, 5)];
    final preview = entry.content.length > 120
        ? "${entry.content.substring(0, 120)}..."
        : entry.content;

    return GestureDetector(
      onTap: onTap,
      onLongPress: onDelete,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.borderColor),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(color: phaseColor, shape: BoxShape.circle),
                ),
                const SizedBox(width: 8),
                Text(
                  entry.exerciseTitle ?? "Free Writing",
                  style: TextStyle(fontFamily: 'SourceCodePro', fontSize: 10, color: phaseColor, letterSpacing: 0.5),
                ),
                const Spacer(),
                Text(
                  DateFormat('MMM d').format(entry.updatedAt),
                  style: const TextStyle(fontFamily: 'SourceCodePro', fontSize: 10, color: AppTheme.textMuted),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(entry.title, style: const TextStyle(
              fontFamily: 'SourceSerif4',
              fontSize: 16,
              color: AppTheme.textPrimary,
              fontWeight: FontWeight.w600,
            )),
            if (preview.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(preview, style: const TextStyle(
                fontFamily: 'CrimsonText',
                fontSize: 14,
                color: AppTheme.textSecondary,
                height: 1.4,
              )),
            ],
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.edit_outlined, size: 12, color: AppTheme.textMuted),
                const SizedBox(width: 4),
                Text("${entry.wordCount} words", style: const TextStyle(
                  fontFamily: 'SourceCodePro',
                  fontSize: 10,
                  color: AppTheme.textMuted,
                )),
                if (entry.tags.contains('imported')) ...[
                  const SizedBox(width: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: AppTheme.inkBlue.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: const Text("imported", style: TextStyle(
                      fontFamily: 'SourceCodePro',
                      fontSize: 9,
                      color: AppTheme.inkBlue,
                    )),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}
