import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../services/app_state.dart';
import '../models/models.dart';
import '../utils/app_theme.dart';
import 'exercise_screen.dart';
import 'write_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(
      builder: (context, state, _) {
        if (state.isLoading) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator(color: AppTheme.goldPrimary)),
          );
        }
        return _HomeContent(state: state);
      },
    );
  }
}

class _HomeContent extends StatelessWidget {
  final AppState state;
  const _HomeContent({required this.state});

  @override
  Widget build(BuildContext context) {
    final progress = state.progress;
    final currentPhase = state.currentPhase;

    return Scaffold(
      backgroundColor: AppTheme.bgDeep,
      body: CustomScrollView(
        slivers: [
          _buildAppBar(context, progress),
          SliverPadding(
            padding: const EdgeInsets.all(20),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                _buildGreeting(progress),
                const SizedBox(height: 24),
                _buildStreakBar(progress),
                const SizedBox(height: 24),
                if (currentPhase != null) ...[
                  _buildCurrentPhaseCard(context, currentPhase),
                  const SizedBox(height: 24),
                ],
                _buildDailyTasks(context),
                const SizedBox(height: 24),
                _buildOverallProgress(),
                const SizedBox(height: 24),
                _buildQuickPrompt(context),
                const SizedBox(height: 100),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  SliverAppBar _buildAppBar(BuildContext context, UserProgress progress) {
    return SliverAppBar(
      expandedHeight: 80,
      floating: true,
      snap: true,
      backgroundColor: AppTheme.bgDeep,
      flexibleSpace: FlexibleSpaceBar(
        titlePadding: const EdgeInsets.only(left: 20, bottom: 16),
        title: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: AppTheme.goldPrimary.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppTheme.goldPrimary.withOpacity(0.4)),
              ),
              child: const Icon(Icons.spiral_outlined, color: AppTheme.goldPrimary, size: 18),
            ),
            const SizedBox(width: 10),
            Text(
              "The Writer's Spiral",
              style: TextStyle(
                fontFamily: 'PlayfairDisplay',
                fontSize: 18,
                color: AppTheme.textPrimary,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
      actions: [
        Container(
          margin: const EdgeInsets.only(right: 20, top: 8, bottom: 8),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(
            color: AppTheme.goldPrimary.withOpacity(0.15),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppTheme.goldPrimary.withOpacity(0.4)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.local_fire_department, color: AppTheme.goldPrimary, size: 16),
              const SizedBox(width: 4),
              Text(
                "${progress.currentStreak}",
                style: const TextStyle(
                  color: AppTheme.goldPrimary,
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildGreeting(UserProgress progress) {
    final hour = DateTime.now().hour;
    String greeting;
    if (hour < 12) greeting = "Good morning, writer.";
    else if (hour < 17) greeting = "Good afternoon, writer.";
    else greeting = "Good evening, writer.";

    final message = progress.wroteToday
        ? "You've written today. Keep going."
        : "The page is waiting.";

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(greeting, style: const TextStyle(
          fontFamily: 'PlayfairDisplay',
          fontSize: 26,
          color: AppTheme.textPrimary,
          fontWeight: FontWeight.w700,
          height: 1.2,
        )).animate().fadeIn(duration: 600.ms).slideX(begin: -0.1),
        const SizedBox(height: 4),
        Text(message, style: const TextStyle(
          fontSize: 16,
          color: AppTheme.textSecondary,
          fontFamily: 'CrimsonText',
          fontStyle: FontStyle.italic,
        )).animate().fadeIn(delay: 200.ms),
      ],
    );
  }

  Widget _buildStreakBar(UserProgress progress) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.goldPrimary.withOpacity(0.15),
            AppTheme.goldDim.withOpacity(0.05),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.goldPrimary.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          _StatChip(
            icon: Icons.local_fire_department,
            value: "${progress.currentStreak}",
            label: "Current Streak",
            color: AppTheme.goldPrimary,
          ),
          _divider(),
          _StatChip(
            icon: Icons.emoji_events,
            value: "${progress.bestStreak}",
            label: "Best Streak",
            color: AppTheme.goldLight,
          ),
          _divider(),
          _StatChip(
            icon: Icons.edit_note,
            value: "${progress.totalWordsWritten}",
            label: "Words Written",
            color: AppTheme.inkBlue,
          ),
        ],
      ),
    ).animate().fadeIn(delay: 300.ms).slideY(begin: 0.1);
  }

  Widget _divider() {
    return Container(
      width: 1,
      height: 40,
      color: AppTheme.borderColor,
      margin: const EdgeInsets.symmetric(horizontal: 12),
    );
  }

  Widget _buildCurrentPhaseCard(BuildContext context, Phase phase) {
    final phaseColor = AppTheme.phaseColors[(phase.id - 1).clamp(0, 5)];

    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => PhaseDetailScreen(phase: phase)),
      ),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppTheme.bgCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: phaseColor.withOpacity(0.4)),
          boxShadow: [
            BoxShadow(color: phaseColor.withOpacity(0.1), blurRadius: 20, offset: const Offset(0, 4)),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: phaseColor.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    "PHASE ${phase.id}",
                    style: TextStyle(
                      fontFamily: 'SourceCodePro',
                      fontSize: 10,
                      color: phaseColor,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
                const Spacer(),
                Icon(Icons.arrow_forward_ios, color: phaseColor.withOpacity(0.6), size: 14),
              ],
            ),
            const SizedBox(height: 12),
            Text(phase.name, style: TextStyle(
              fontFamily: 'PlayfairDisplay',
              fontSize: 22,
              color: phaseColor,
              fontWeight: FontWeight.w700,
            )),
            Text(phase.subtitle, style: const TextStyle(
              fontFamily: 'CrimsonText',
              fontSize: 15,
              color: AppTheme.textSecondary,
              fontStyle: FontStyle.italic,
            )),
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: phase.progressPercent,
                backgroundColor: phaseColor.withOpacity(0.1),
                valueColor: AlwaysStoppedAnimation<Color>(phaseColor),
                minHeight: 6,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "${phase.completedExercises} / ${phase.totalExercises} exercises",
                  style: TextStyle(fontFamily: 'SourceCodePro', fontSize: 11, color: phaseColor.withOpacity(0.8)),
                ),
                Text(
                  "${(phase.progressPercent * 100).toInt()}%",
                  style: TextStyle(fontFamily: 'SourceCodePro', fontSize: 11, color: phaseColor, fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ],
        ),
      ).animate().fadeIn(delay: 400.ms).slideY(begin: 0.1),
    );
  }

  Widget _buildDailyTasks(BuildContext context) {
    final today = DateTime.now();
    final tasks = _getDailyTasks(today);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Today's Practice", style: TextStyle(
          fontFamily: 'PlayfairDisplay',
          fontSize: 18,
          color: AppTheme.textPrimary,
          fontWeight: FontWeight.w600,
        )),
        const SizedBox(height: 12),
        ...tasks.asMap().entries.map((entry) {
          return _DailyTaskCard(task: entry.value, delay: entry.key * 100)
              .animate()
              .fadeIn(delay: Duration(milliseconds: 500 + entry.key * 100))
              .slideX(begin: 0.05);
        }),
      ],
    );
  }

  List<DailyTask> _getDailyTasks(DateTime today) {
    return [
      DailyTask(
        id: "brain_drain",
        title: "Brain Drain",
        description: "10 minutes of free writing — no rules, no judgement. Just write.",
        type: DailyTaskType.brainDrain,
        targetMinutes: 10,
      ),
      DailyTask(
        id: "exercise",
        title: "Workshop Exercise",
        description: "Complete one exercise from your current phase.",
        type: DailyTaskType.exercise,
        targetMinutes: 20,
      ),
      DailyTask(
        id: "observation",
        title: "Observe & Note",
        description: "Notice one interesting detail about a person or place today. Write it down.",
        type: DailyTaskType.reflection,
        targetMinutes: 5,
      ),
    ];
  }

  Widget _buildOverallProgress() {
    final overallProgress = state.getOverallProgress();
    final unlockedPhases = state.phases.where((p) => p.isUnlocked).length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text("Your Spiral Journey", style: TextStyle(
              fontFamily: 'PlayfairDisplay',
              fontSize: 18,
              color: AppTheme.textPrimary,
              fontWeight: FontWeight.w600,
            )),
            const Spacer(),
            Text(
              "$unlockedPhases/6 phases",
              style: const TextStyle(
                fontFamily: 'SourceCodePro',
                fontSize: 11,
                color: AppTheme.textMuted,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: state.phases.asMap().entries.map((entry) {
            final phase = entry.value;
            final color = AppTheme.phaseColors[entry.key];
            return Expanded(
              child: Container(
                margin: const EdgeInsets.only(right: 4),
                child: Column(
                  children: [
                    Container(
                      height: 6,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(3),
                        color: phase.isUnlocked
                            ? color.withOpacity(phase.progressPercent > 0 ? 1.0 : 0.3)
                            : AppTheme.borderColor,
                      ),
                      child: phase.isUnlocked && phase.progressPercent > 0
                          ? FractionallySizedBox(
                              widthFactor: phase.progressPercent,
                              alignment: Alignment.centerLeft,
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(3),
                                  color: color,
                                ),
                              ),
                            )
                          : null,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      "P${entry.key + 1}",
                      style: TextStyle(
                        fontFamily: 'SourceCodePro',
                        fontSize: 9,
                        color: phase.isUnlocked ? color : AppTheme.textMuted,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    if (!phase.isUnlocked)
                      const Icon(Icons.lock, size: 10, color: AppTheme.textMuted),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildQuickPrompt(BuildContext context) {
    final prompts = state.prompts;
    if (prompts.isEmpty) return const SizedBox.shrink();

    final randomPrompt = prompts[DateTime.now().day % prompts.length];

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.violet.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.lightbulb_outline, color: AppTheme.violet, size: 18),
              const SizedBox(width: 8),
              Text("Prompt of the Day", style: TextStyle(
                fontFamily: 'SourceCodePro',
                fontSize: 11,
                color: AppTheme.violet,
                letterSpacing: 1,
              )),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            randomPrompt.text,
            style: const TextStyle(
              fontFamily: 'CrimsonText',
              fontSize: 18,
              color: AppTheme.textPrimary,
              height: 1.5,
              fontStyle: FontStyle.italic,
            ),
          ),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => WriteScreen(prompt: randomPrompt.text)),
            ),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              decoration: BoxDecoration(
                color: AppTheme.violet.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.violet.withOpacity(0.4)),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.edit, color: AppTheme.violet, size: 16),
                  SizedBox(width: 8),
                  Text("Write from this prompt", style: TextStyle(
                    color: AppTheme.violet,
                    fontFamily: 'SourceCodePro',
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  )),
                ],
              ),
            ),
          ),
        ],
      ),
    ).animate().fadeIn(delay: 700.ms);
  }
}

class _StatChip extends StatelessWidget {
  final IconData icon;
  final String value, label;
  final Color color;

  const _StatChip({required this.icon, required this.value, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 4),
          Text(value, style: TextStyle(
            color: color,
            fontSize: 20,
            fontWeight: FontWeight.w800,
            fontFamily: 'PlayfairDisplay',
          )),
          Text(label, style: const TextStyle(
            color: AppTheme.textMuted,
            fontSize: 10,
            fontFamily: 'SourceCodePro',
            letterSpacing: 0.3,
          ), textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

class _DailyTaskCard extends StatelessWidget {
  final DailyTask task;
  final int delay;

  const _DailyTaskCard({required this.task, required this.delay});

  @override
  Widget build(BuildContext context) {
    Color color;
    IconData icon;
    switch (task.type) {
      case DailyTaskType.brainDrain:
        color = AppTheme.goldPrimary;
        icon = Icons.water_drop_outlined;
        break;
      case DailyTaskType.exercise:
        color = AppTheme.inkBlue;
        icon = Icons.fitness_center_outlined;
        break;
      default:
        color = AppTheme.emerald;
        icon = Icons.visibility_outlined;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderColor),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(task.title, style: const TextStyle(
                  fontFamily: 'SourceSerif4',
                  fontSize: 15,
                  color: AppTheme.textPrimary,
                  fontWeight: FontWeight.w600,
                )),
                const SizedBox(height: 2),
                Text(task.description, style: const TextStyle(
                  fontFamily: 'CrimsonText',
                  fontSize: 13,
                  color: AppTheme.textSecondary,
                )),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Column(
            children: [
              Text("${task.targetMinutes}m", style: TextStyle(
                fontFamily: 'SourceCodePro',
                fontSize: 12,
                color: color.withOpacity(0.8),
                fontWeight: FontWeight.w600,
              )),
              const SizedBox(height: 4),
              Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  border: Border.all(color: AppTheme.borderColor, width: 1.5),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: task.isCompleted
                    ? Icon(Icons.check, size: 14, color: color)
                    : null,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// Phase Detail Screen (shown when tapping current phase card)
class PhaseDetailScreen extends StatelessWidget {
  final Phase phase;
  const PhaseDetailScreen({super.key, required this.phase});

  @override
  Widget build(BuildContext context) {
    final phaseColor = AppTheme.phaseColors[(phase.id - 1).clamp(0, 5)];

    return Scaffold(
      backgroundColor: AppTheme.bgDeep,
      appBar: AppBar(
        backgroundColor: AppTheme.bgDeep,
        title: Text("Phase ${phase.id}: ${phase.name}"),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: phaseColor.withOpacity(0.08),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: phaseColor.withOpacity(0.3)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(phase.subtitle, style: TextStyle(
                  fontFamily: 'CrimsonText',
                  fontSize: 16,
                  color: phaseColor,
                  fontStyle: FontStyle.italic,
                )),
                const SizedBox(height: 8),
                Text(phase.description, style: const TextStyle(
                  fontFamily: 'CrimsonText',
                  fontSize: 16,
                  color: AppTheme.textSecondary,
                  height: 1.6,
                )),
                const SizedBox(height: 16),
                LinearProgressIndicator(
                  value: phase.progressPercent,
                  backgroundColor: phaseColor.withOpacity(0.1),
                  valueColor: AlwaysStoppedAnimation<Color>(phaseColor),
                  minHeight: 6,
                ),
                const SizedBox(height: 8),
                Text("${phase.completedExercises} of ${phase.totalExercises} exercises completed",
                  style: TextStyle(fontFamily: 'SourceCodePro', fontSize: 11, color: phaseColor)),
              ],
            ),
          ),
          const SizedBox(height: 24),
          ...phase.modules.map((module) => _ModuleCard(module: module, phaseColor: phaseColor)),
        ],
      ),
    );
  }
}

class _ModuleCard extends StatefulWidget {
  final Module module;
  final Color phaseColor;
  const _ModuleCard({required this.module, required this.phaseColor});

  @override
  State<_ModuleCard> createState() => _ModuleCardState();
}

class _ModuleCardState extends State<_ModuleCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderColor),
      ),
      child: Column(
        children: [
          GestureDetector(
            onTap: () => setState(() => _expanded = !_expanded),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: widget.module.isComplete ? widget.phaseColor : AppTheme.textMuted,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(widget.module.title, style: const TextStyle(
                      fontFamily: 'SourceSerif4',
                      fontSize: 16,
                      color: AppTheme.textPrimary,
                      fontWeight: FontWeight.w600,
                    )),
                  ),
                  Text("${widget.module.completedCount}/${widget.module.exercises.length}",
                    style: TextStyle(fontFamily: 'SourceCodePro', fontSize: 11, color: widget.phaseColor)),
                  const SizedBox(width: 8),
                  Icon(_expanded ? Icons.expand_less : Icons.expand_more,
                    color: AppTheme.textMuted, size: 20),
                ],
              ),
            ),
          ),
          if (_expanded) ...[
            Divider(color: AppTheme.borderColor, height: 1),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.module.theory, style: const TextStyle(
                    fontFamily: 'CrimsonText',
                    fontSize: 15,
                    color: AppTheme.textSecondary,
                    height: 1.6,
                    fontStyle: FontStyle.italic,
                  )),
                  const SizedBox(height: 16),
                  ...widget.module.exercises.map((exercise) => _ExerciseRow(
                    exercise: exercise,
                    phaseColor: widget.phaseColor,
                  )),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _ExerciseRow extends StatelessWidget {
  final Exercise exercise;
  final Color phaseColor;
  const _ExerciseRow({required this.exercise, required this.phaseColor});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ExerciseScreen(exercise: exercise)),
      ),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: exercise.isCompleted
              ? phaseColor.withOpacity(0.08)
              : AppTheme.bgElevated,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: exercise.isCompleted ? phaseColor.withOpacity(0.3) : AppTheme.borderColor,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                color: exercise.isCompleted
                    ? phaseColor
                    : AppTheme.borderColor,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                exercise.isCompleted ? Icons.check : Icons.edit_outlined,
                size: 14,
                color: exercise.isCompleted ? AppTheme.bgDeep : AppTheme.textMuted,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(exercise.title, style: TextStyle(
                    fontFamily: 'SourceSerif4',
                    fontSize: 14,
                    color: exercise.isCompleted ? phaseColor : AppTheme.textPrimary,
                    fontWeight: FontWeight.w600,
                  )),
                  Text("~${exercise.estimatedMinutes} min", style: const TextStyle(
                    fontFamily: 'SourceCodePro',
                    fontSize: 10,
                    color: AppTheme.textMuted,
                  )),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, size: 12, color: AppTheme.textMuted),
          ],
        ),
      ),
    );
  }
}
