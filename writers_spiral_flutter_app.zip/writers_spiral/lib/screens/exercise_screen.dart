import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/models.dart';
import '../services/app_state.dart';
import '../services/ai_service.dart';
import '../utils/app_theme.dart';
import 'write_screen.dart';

class ExerciseScreen extends StatefulWidget {
  final Exercise exercise;
  const ExerciseScreen({super.key, required this.exercise});

  @override
  State<ExerciseScreen> createState() => _ExerciseScreenState();
}

class _ExerciseScreenState extends State<ExerciseScreen> {
  bool _timerRunning = false;
  int _secondsRemaining = 0;
  int _totalSeconds = 0;
  Timer? _timer;
  String? _aiFeedback;
  bool _loadingFeedback = false;
  WritingEntry? _currentEntry;

  @override
  void initState() {
    super.initState();
    _totalSeconds = widget.exercise.estimatedMinutes * 60;
    _secondsRemaining = _totalSeconds;
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _startTimer() {
    setState(() => _timerRunning = true);
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_secondsRemaining <= 0) {
        t.cancel();
        setState(() => _timerRunning = false);
        _onTimerComplete();
      } else {
        setState(() => _secondsRemaining--);
      }
    });
  }

  void _pauseTimer() {
    _timer?.cancel();
    setState(() => _timerRunning = false);
  }

  void _resetTimer() {
    _timer?.cancel();
    setState(() {
      _timerRunning = false;
      _secondsRemaining = _totalSeconds;
    });
  }

  void _onTimerComplete() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.bgCard,
        title: const Text("Time's up!", style: TextStyle(color: AppTheme.goldPrimary, fontFamily: 'PlayfairDisplay')),
        content: const Text("Your writing time is complete. How did it go?", style: TextStyle(color: AppTheme.textSecondary)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Keep writing", style: TextStyle(color: AppTheme.textSecondary))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.goldPrimary),
            onPressed: () {
              Navigator.pop(context);
              _markComplete();
            },
            child: const Text("Mark complete", style: TextStyle(color: AppTheme.bgDeep, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }

  Future<void> _markComplete() async {
    final state = context.read<AppState>();
    await state.markExerciseCompleted(widget.exercise.id, widget.exercise.phaseId);

    if (!mounted) return;

    showDialog(
      context: context,
      builder: (_) => _CompletionDialog(
        exercise: widget.exercise,
        onContinue: () {
          Navigator.pop(context);
          Navigator.pop(context);
        },
      ),
    );
  }

  Future<void> _openWritingPad() async {
    final state = context.read<AppState>();
    final entry = await state.createWritingEntry(
      exerciseId: widget.exercise.id,
      exerciseTitle: widget.exercise.title,
      phaseId: widget.exercise.phaseId,
    );

    if (!mounted) return;

    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => WriteScreen(
          entry: entry,
          prompt: widget.exercise.prompt,
          exerciseTitle: widget.exercise.title,
          onComplete: () => _markComplete(),
        ),
      ),
    );
    setState(() => _currentEntry = entry);
  }

  String get _timerDisplay {
    final m = _secondsRemaining ~/ 60;
    final s = _secondsRemaining % 60;
    return "${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}";
  }

  double get _timerProgress {
    if (_totalSeconds == 0) return 0;
    return 1 - (_secondsRemaining / _totalSeconds);
  }

  @override
  Widget build(BuildContext context) {
    final phaseColor = AppTheme.phaseColors[(widget.exercise.phaseId - 1).clamp(0, 5)];

    return Scaffold(
      backgroundColor: AppTheme.bgDeep,
      appBar: AppBar(
        backgroundColor: AppTheme.bgDeep,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text("Phase ${widget.exercise.phaseId}"),
        actions: [
          if (widget.exercise.isCompleted)
            Container(
              margin: const EdgeInsets.only(right: 16),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppTheme.emerald.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Row(
                children: [
                  Icon(Icons.check_circle, color: AppTheme.emerald, size: 14),
                  SizedBox(width: 4),
                  Text("Done", style: TextStyle(color: AppTheme.emerald, fontSize: 12, fontFamily: 'SourceCodePro')),
                ],
              ),
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Exercise type badge
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: phaseColor.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                widget.exercise.type.name.toUpperCase().replaceAll('_', ' '),
                style: TextStyle(fontFamily: 'SourceCodePro', fontSize: 10, color: phaseColor, letterSpacing: 1.2),
              ),
            ),
            const SizedBox(height: 12),
            // Title
            Text(widget.exercise.title, style: const TextStyle(
              fontFamily: 'PlayfairDisplay',
              fontSize: 26,
              color: AppTheme.textPrimary,
              fontWeight: FontWeight.w700,
              height: 1.2,
            )),
            const SizedBox(height: 24),

            // Timer
            _buildTimer(phaseColor),
            const SizedBox(height: 28),

            // Instructions
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppTheme.bgCard,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppTheme.borderColor),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.format_list_bulleted, color: AppTheme.inkBlue, size: 16),
                      SizedBox(width: 8),
                      Text("Instructions", style: TextStyle(
                        fontFamily: 'SourceCodePro',
                        fontSize: 11,
                        color: AppTheme.inkBlue,
                        letterSpacing: 1,
                      )),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(widget.exercise.instruction, style: const TextStyle(
                    fontFamily: 'CrimsonText',
                    fontSize: 17,
                    color: AppTheme.textPrimary,
                    height: 1.7,
                  )),
                ],
              ),
            ),

            if (widget.exercise.prompt != null) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [phaseColor.withOpacity(0.1), phaseColor.withOpacity(0.03)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: phaseColor.withOpacity(0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.format_quote, color: phaseColor, size: 16),
                        const SizedBox(width: 8),
                        Text("Starting Prompt", style: TextStyle(
                          fontFamily: 'SourceCodePro',
                          fontSize: 11,
                          color: phaseColor,
                          letterSpacing: 1,
                        )),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(widget.exercise.prompt!, style: const TextStyle(
                      fontFamily: 'CrimsonText',
                      fontSize: 18,
                      color: AppTheme.textPrimary,
                      height: 1.6,
                      fontStyle: FontStyle.italic,
                    )),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 28),

            // Action buttons
            _buildActionButtons(context, phaseColor),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildTimer(Color phaseColor) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: phaseColor.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          // Circular timer
          SizedBox(
            width: 100,
            height: 100,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CircularProgressIndicator(
                  value: _timerProgress,
                  backgroundColor: phaseColor.withOpacity(0.1),
                  valueColor: AlwaysStoppedAnimation<Color>(phaseColor),
                  strokeWidth: 6,
                ),
                Text(
                  _timerDisplay,
                  style: TextStyle(
                    fontFamily: 'SourceCodePro',
                    fontSize: 20,
                    color: phaseColor,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _timerRunning ? "Writing in progress..." : "Focus Timer",
                  style: const TextStyle(
                    fontFamily: 'SourceSerif4',
                    fontSize: 15,
                    color: AppTheme.textPrimary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  "${widget.exercise.estimatedMinutes} minute exercise",
                  style: const TextStyle(
                    fontFamily: 'SourceCodePro',
                    fontSize: 11,
                    color: AppTheme.textMuted,
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    _TimerButton(
                      label: _timerRunning ? "Pause" : "Start",
                      icon: _timerRunning ? Icons.pause : Icons.play_arrow,
                      color: phaseColor,
                      onTap: _timerRunning ? _pauseTimer : _startTimer,
                    ),
                    const SizedBox(width: 8),
                    _TimerButton(
                      label: "Reset",
                      icon: Icons.replay,
                      color: AppTheme.textMuted,
                      onTap: _resetTimer,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(BuildContext context, Color phaseColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Primary: Open Writing Pad
        GestureDetector(
          onTap: _openWritingPad,
          child: Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [phaseColor, phaseColor.withOpacity(0.7)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [BoxShadow(color: phaseColor.withOpacity(0.3), blurRadius: 16, offset: const Offset(0, 4))],
            ),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.edit, color: Colors.white, size: 20),
                SizedBox(width: 10),
                Text("Open Writing Pad", style: TextStyle(
                  fontFamily: 'SourceSerif4',
                  fontSize: 16,
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                )),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        // Secondary: Mark complete (if already wrote)
        if (!widget.exercise.isCompleted)
          GestureDetector(
            onTap: _markComplete,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.bgCard,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppTheme.borderColor),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.check_circle_outline, color: AppTheme.emerald, size: 18),
                  SizedBox(width: 8),
                  Text("Mark as Complete", style: TextStyle(
                    fontFamily: 'SourceSerif4',
                    fontSize: 15,
                    color: AppTheme.emerald,
                    fontWeight: FontWeight.w600,
                  )),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

class _TimerButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _TimerButton({required this.label, required this.icon, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 14, color: color),
            const SizedBox(width: 4),
            Text(label, style: TextStyle(
              fontFamily: 'SourceCodePro',
              fontSize: 11,
              color: color,
              fontWeight: FontWeight.w600,
            )),
          ],
        ),
      ),
    );
  }
}

class _CompletionDialog extends StatelessWidget {
  final Exercise exercise;
  final VoidCallback onContinue;

  const _CompletionDialog({required this.exercise, required this.onContinue});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: AppTheme.bgCard,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: AppTheme.goldPrimary.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.auto_awesome, color: AppTheme.goldPrimary, size: 32),
          ),
          const SizedBox(height: 16),
          const Text("Exercise Complete!", style: TextStyle(
            fontFamily: 'PlayfairDisplay',
            fontSize: 20,
            color: AppTheme.goldPrimary,
            fontWeight: FontWeight.w700,
          )),
          const SizedBox(height: 8),
          Text(
            "\"${exercise.title}\" — done.",
            style: const TextStyle(fontFamily: 'CrimsonText', fontSize: 16, color: AppTheme.textSecondary),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 4),
          const Text(
            "Every exercise completed is a loop of the spiral — you return to the same ideas at a higher level.",
            style: TextStyle(fontFamily: 'CrimsonText', fontSize: 14, color: AppTheme.textMuted, fontStyle: FontStyle.italic),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.goldPrimary,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: onContinue,
              child: const Text("Continue", style: TextStyle(
                color: AppTheme.bgDeep,
                fontFamily: 'SourceSerif4',
                fontWeight: FontWeight.w700,
                fontSize: 16,
              )),
            ),
          ),
        ],
      ),
    );
  }
}
