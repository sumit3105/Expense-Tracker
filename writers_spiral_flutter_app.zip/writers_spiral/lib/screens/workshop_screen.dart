import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../services/app_state.dart';
import '../models/models.dart';
import '../utils/app_theme.dart';
import 'home_screen.dart' show PhaseDetailScreen;
import 'prompt_screen.dart';

class WorkshopScreen extends StatelessWidget {
  const WorkshopScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(
      builder: (context, state, _) {
        if (state.isLoading) {
          return const Scaffold(body: Center(child: CircularProgressIndicator(color: AppTheme.goldPrimary)));
        }
        return _WorkshopContent(state: state);
      },
    );
  }
}

class _WorkshopContent extends StatelessWidget {
  final AppState state;
  const _WorkshopContent({required this.state});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDeep,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            floating: true,
            snap: true,
            backgroundColor: AppTheme.bgDeep,
            title: const Text("Workshop"),
            actions: [
              IconButton(
                icon: const Icon(Icons.psychology_outlined, color: AppTheme.violet),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PromptScreen())),
                tooltip: "Prompt Bank",
              ),
            ],
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                _buildUnlockProgress(),
                const SizedBox(height: 24),
                ...state.phases.asMap().entries.map((entry) {
                  return _PhaseCard(phase: entry.value, index: entry.key)
                      .animate()
                      .fadeIn(delay: Duration(milliseconds: entry.key * 100))
                      .slideY(begin: 0.05);
                }),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUnlockProgress() {
    final completed = state.progress.totalExercisesCompleted;
    final phases = state.phases;

    // Find next unlock
    int nextUnlock = -1;
    String? nextPhaseName;
    for (int i = 0; i < phases.length; i++) {
      if (!phases[i].isUnlocked) {
        nextUnlock = AppConstants.phaseUnlockRequirements[i];
        nextPhaseName = phases[i].name;
        break;
      }
    }

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.workspace_premium, color: AppTheme.goldPrimary, size: 16),
              const SizedBox(width: 8),
              Text("$completed exercises completed", style: const TextStyle(
                fontFamily: 'SourceCodePro',
                fontSize: 12,
                color: AppTheme.goldPrimary,
                fontWeight: FontWeight.w600,
              )),
            ],
          ),
          if (nextUnlock > 0 && nextPhaseName != null) ...[
            const SizedBox(height: 10),
            LinearProgressIndicator(
              value: completed / nextUnlock,
              backgroundColor: AppTheme.borderColor,
              valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.goldPrimary),
              minHeight: 4,
            ),
            const SizedBox(height: 6),
            Text(
              "${nextUnlock - completed} more exercises to unlock Phase: $nextPhaseName",
              style: const TextStyle(fontFamily: 'CrimsonText', fontSize: 13, color: AppTheme.textMuted),
            ),
          ] else ...[
            const SizedBox(height: 6),
            const Text("All phases unlocked! The spiral continues.", style: TextStyle(
              fontFamily: 'CrimsonText',
              fontSize: 13,
              color: AppTheme.goldPrimary,
              fontStyle: FontStyle.italic,
            )),
          ],
        ],
      ),
    );
  }
}

class _PhaseCard extends StatelessWidget {
  final Phase phase;
  final int index;

  const _PhaseCard({required this.phase, required this.index});

  @override
  Widget build(BuildContext context) {
    final color = AppTheme.phaseColors[index.clamp(0, 5)];
    final isLocked = !phase.isUnlocked;

    return GestureDetector(
      onTap: isLocked
          ? () => _showLockedDialog(context, phase)
          : () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => PhaseDetailScreen(phase: phase)),
            ),
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          color: isLocked ? AppTheme.locked : AppTheme.bgCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isLocked ? AppTheme.lockedBorder : color.withOpacity(0.4),
          ),
        ),
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Phase number circle
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: isLocked ? AppTheme.lockedBorder : color.withOpacity(0.15),
                      border: Border.all(
                        color: isLocked ? AppTheme.lockedBorder : color.withOpacity(0.5),
                        width: 2,
                      ),
                    ),
                    child: isLocked
                        ? const Icon(Icons.lock, color: AppTheme.textMuted, size: 20)
                        : Center(
                            child: Text(
                              "${phase.id}",
                              style: TextStyle(
                                fontFamily: 'PlayfairDisplay',
                                fontSize: 22,
                                color: color,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          phase.name,
                          style: TextStyle(
                            fontFamily: 'PlayfairDisplay',
                            fontSize: 20,
                            color: isLocked ? AppTheme.textMuted : color,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Text(
                          phase.subtitle,
                          style: TextStyle(
                            fontFamily: 'CrimsonText',
                            fontSize: 15,
                            color: isLocked ? AppTheme.textMuted.withOpacity(0.5) : AppTheme.textSecondary,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                        if (isLocked) ...[
                          const SizedBox(height: 6),
                          _UnlockRequirementBadge(phase: phase),
                        ],
                      ],
                    ),
                  ),
                  if (!isLocked)
                    Icon(Icons.arrow_forward_ios, color: color.withOpacity(0.5), size: 14),
                ],
              ),
            ),

            if (!isLocked) ...[
              // Progress bar
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: phase.progressPercent,
                    backgroundColor: color.withOpacity(0.1),
                    valueColor: AlwaysStoppedAnimation<Color>(color),
                    minHeight: 4,
                  ),
                ),
              ),

              // Module previews
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: phase.modules.map((module) {
                    return _ModulePreviewRow(module: module, color: color);
                  }).toList(),
                ),
              ),
            ] else ...[
              // Locked description
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                child: Text(
                  phase.description,
                  style: const TextStyle(
                    fontFamily: 'CrimsonText',
                    fontSize: 14,
                    color: AppTheme.textMuted,
                    height: 1.5,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  void _showLockedDialog(BuildContext context, Phase phase) {
    final required = AppConstants.phaseUnlockRequirements[phase.id - 1];
    final current = context.read<AppState>().progress.totalExercisesCompleted;
    final needed = required - current;

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.bgCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.lock, color: AppTheme.textMuted, size: 40),
            const SizedBox(height: 12),
            Text("Phase ${phase.id}: ${phase.name}", style: const TextStyle(
              fontFamily: 'PlayfairDisplay',
              fontSize: 18,
              color: AppTheme.textPrimary,
              fontWeight: FontWeight.w700,
            )),
            const SizedBox(height: 8),
            Text(
              "Complete $needed more exercises to unlock this phase. The spiral rewards those who show up.",
              style: const TextStyle(fontFamily: 'CrimsonText', fontSize: 15, color: AppTheme.textSecondary, height: 1.5),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            LinearProgressIndicator(
              value: current / required,
              backgroundColor: AppTheme.borderColor,
              valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.goldPrimary),
              minHeight: 6,
            ),
            const SizedBox(height: 6),
            Text("$current / $required exercises", style: const TextStyle(
              fontFamily: 'SourceCodePro',
              fontSize: 11,
              color: AppTheme.textMuted,
            )),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Keep writing", style: TextStyle(color: AppTheme.goldPrimary)),
          ),
        ],
      ),
    );
  }
}

class _UnlockRequirementBadge extends StatelessWidget {
  final Phase phase;
  const _UnlockRequirementBadge({required this.phase});

  @override
  Widget build(BuildContext context) {
    final required = AppConstants.phaseUnlockRequirements[phase.id - 1];
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: AppTheme.lockedBorder,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        "Unlocks at $required exercises",
        style: const TextStyle(fontFamily: 'SourceCodePro', fontSize: 10, color: AppTheme.textMuted),
      ),
    );
  }
}

class _ModulePreviewRow extends StatelessWidget {
  final Module module;
  final Color color;

  const _ModulePreviewRow({required this.module, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppTheme.bgElevated,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: module.isComplete ? color : AppTheme.borderColor,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(module.title, style: const TextStyle(
            fontFamily: 'SourceSerif4',
            fontSize: 13,
            color: AppTheme.textSecondary,
          ))),
          Text("${module.completedCount}/${module.exercises.length}",
            style: TextStyle(fontFamily: 'SourceCodePro', fontSize: 10, color: color.withOpacity(0.7))),
        ],
      ),
    );
  }
}
